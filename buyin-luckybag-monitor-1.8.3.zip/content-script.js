(function () {
  const ROOT_ID = 'buyin-luckybag-monitor-root';
  const TOAST_ID = 'buyin-luckybag-monitor-toast-root';
  const STYLE_ID = 'buyin-luckybag-monitor-style';
  const END_TEXT = '没有更多了';
  const DEFAULT_MIN_INTERVAL = 2000;
  const DEFAULT_MAX_INTERVAL = 3000;
  const MIN_ALLOWED_INTERVAL = 500;
  const STORAGE_KEYS = {
    auth: 'buyinAuthState',
    users: 'buyinUsers',
    userSettings: 'buyinUserSettings',
    categories: 'buyinCategories',
    monitorConfig: 'buyinMonitorConfig',
    prizeLibrary: 'buyinPrizeLibrary',
  };
  const LONG_PRESS_MS = 420;
  const DEFAULT_MONITOR_CONFIG = {
    targetPath: '/pc/selection/common/material_list',
    allRequestTemplate: { filters: {} },
    categoryRequestTemplate: { filters: { BusinessCid: { value: ['__CATEGORY_ID__'] } } },
    requestTemplate: { filters: { BusinessCid: { value: ['__CATEGORY_ID__'] } } },
  };

  const DEFAULT_CATEGORIES = [
    { name: '全部', value: null },
    { name: '美妆', value: '9' },
    { name: '智能家居', value: '7' },
    { name: '3C数码家电', value: '14' },
    { name: '个护家清', value: '5' },
    { name: '珠宝文玩', value: '20' },
    { name: '服饰内衣', value: '4' },
    { name: '食品饮料', value: '13' },
    { name: '母婴宠物', value: '10' },
    { name: '运动户外', value: '18' },
    { name: '玩具乐器', value: '2' },
    { name: '酒类', value: '23' },
    { name: '钟表配饰', value: '19' },
    { name: '礼品文创', value: '6' },
    { name: '鲜花园艺', value: '11' },
    { name: '图书教育', value: '15' },
    { name: '鞋靴箱包', value: '16' },
    { name: '滋补保健', value: '24' },
    { name: '虚拟充值', value: '17' },
    { name: '生鲜', value: '8' },
  ];

  if (window.__buyinLuckybagMonitorInstalled) return;
  window.__buyinLuckybagMonitorInstalled = true;

  let root;
  let accountNameEl;
  let authActionEl;
  let statusEl;
  let categoryEl;
  let countEl;
  let categoryGridEl;
  let selectToggleButton;
  let collectButton;
  let collectStatusEl;
  let responseBodyEl;
  let responseMetaEl;
  let copyButton;
  let responseEmptyEl;
  let toastRoot;
  let minIntervalInput;
  let maxIntervalInput;
  let lastResponseText = '';
  let lastPayload = null;
  let prizeLibraryWriteQueue = Promise.resolve();
  let authState = { mode: 'guest', username: '' };
  let monitorConfig = cloneJson(DEFAULT_MONITOR_CONFIG);
  let categories = normalizeCategoryList(DEFAULT_CATEGORIES.slice());
  let selectedCategoryKeys = new Set();
  let collecting = false;
  let collectTimer = 0;
  let endObserver = null;
  let lastScrollResult = null;
  let nextDelay = 0;
  let collectionQueue = [];
  let activeCategory = null;
  let waitingForCategoryPayload = false;
  let switchingCategory = false;
  let advancingCategory = false;
  let ignoredEndMarkers = new WeakSet();
  let categoryScrollCount = 0;
  let dragState = null;
  let longPressTimer = 0;
  let clickTimer = 0;
  let suppressClickUntil = 0;
  let ignoreEndUntil = 0;

  injectStyle();
  mountWhenReady();
  injectPageHook();

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      #${ROOT_ID} {
        position: fixed;
        top: 16px;
        right: 24px;
        width: min(460px, calc(100vw - 48px));
        max-height: calc(100vh - 32px);
        z-index: 2147483647;
        box-sizing: border-box;
        display: grid;
        gap: 10px;
        font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        color: #172033;
        --panel-bg: rgba(255, 255, 255, 0.94);
        --panel-soft: #f7f8fa;
        --panel-line: rgba(15, 23, 42, 0.1);
        --panel-text: #111827;
        --panel-muted: #6b7280;
        --panel-accent: #111827;
        --panel-blue: #2563eb;
        --panel-radius: 16px;
      }
      #${ROOT_ID}, #${ROOT_ID} * { box-sizing: border-box; }
      #${ROOT_ID} .mini-icon {
        width: 15px;
        height: 15px;
        flex: 0 0 auto;
        fill: none;
        stroke: currentColor;
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
      }
      #${ROOT_ID} .monitor-card {
        overflow: hidden;
        background: var(--panel-bg);
        border: 1px solid var(--panel-line);
        border-radius: var(--panel-radius);
        box-shadow: 0 24px 70px rgba(15, 23, 42, 0.18), 0 2px 10px rgba(15, 23, 42, 0.06);
        backdrop-filter: blur(18px) saturate(1.2);
      }
      #${ROOT_ID} .monitor-card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        min-height: 42px;
        padding: 10px 12px;
        border-bottom: 1px solid rgba(148, 163, 184, 0.24);
        background: rgba(255, 255, 255, 0.7);
      }
      #${ROOT_ID} .monitor-title {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        margin: 0;
        font-size: 13px;
        line-height: 1.3;
        font-weight: 700;
        letter-spacing: 0;
        color: var(--panel-text);
      }
      #${ROOT_ID} .monitor-status {
        flex: 0 0 auto;
        font-size: 12px;
        color: var(--panel-blue);
        white-space: nowrap;
      }
      #${ROOT_ID} .account-strip {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 9px 12px;
        border-bottom: 1px solid rgba(148, 163, 184, 0.18);
        background: rgba(255, 255, 255, 0.58);
      }
      #${ROOT_ID} .account-name {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
        padding: 0;
        border: 0;
        background: transparent;
        color: var(--panel-text);
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      #${ROOT_ID} .auth-action {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        flex: 0 0 auto;
        height: 28px;
        padding: 0 10px;
        border: 1px solid rgba(17, 24, 39, 0.12);
        border-radius: 999px;
        background: #ffffff;
        color: var(--panel-text);
        font-size: 12px;
        cursor: pointer;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
      }
      #${ROOT_ID} .monitor-section { padding: 12px; }
      #${ROOT_ID} .monitor-section + .monitor-section { border-top: 1px solid rgba(148, 163, 184, 0.18); }
      #${ROOT_ID} .metrics {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
      }
      #${ROOT_ID} .metric {
        min-width: 0;
        padding: 9px 10px;
        background: var(--panel-soft);
        border: 1px solid rgba(15, 23, 42, 0.08);
        border-radius: 14px;
      }
      #${ROOT_ID} .metric-label {
        margin-bottom: 4px;
        font-size: 12px;
        color: var(--panel-muted);
        line-height: 1.3;
      }
      #${ROOT_ID} .metric-value {
        overflow-wrap: anywhere;
        font-size: 15px;
        line-height: 1.35;
        font-weight: 700;
        color: var(--panel-text);
      }
      #${ROOT_ID} .section-heading {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        margin-bottom: 8px;
      }
      #${ROOT_ID} .section-title {
        margin: 0;
        font-size: 12px;
        font-weight: 700;
        color: var(--panel-text);
      }
      #${ROOT_ID} .category-actions {
        display: flex;
        gap: 6px;
      }
      #${ROOT_ID} .category-action {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        height: 28px;
        padding: 0 10px;
        border: 1px solid rgba(17, 24, 39, 0.12);
        border-radius: 999px;
        background: #ffffff;
        color: var(--panel-text);
        font-size: 12px;
        cursor: pointer;
      }
      #${ROOT_ID} .category-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      #${ROOT_ID} .category-button, #${ROOT_ID} .category-add-button {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        min-height: 30px;
        max-width: 100%;
        padding: 0 10px;
        border: 1px solid rgba(17, 24, 39, 0.1);
        border-radius: 999px;
        background: #ffffff;
        color: #374151;
        font-size: 12px;
        cursor: pointer;
        user-select: none;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
      }
      #${ROOT_ID} .category-button.is-selected {
        border-color: rgba(37, 99, 235, 0.34);
        background: #eff6ff;
        color: #1d4ed8;
        font-weight: 700;
      }
      #${ROOT_ID} .category-button.is-active-collecting {
        border-color: #16a34a;
        background: #dcfce7;
        color: #166534;
      }
      #${ROOT_ID} .category-button.is-locked {
        cursor: pointer;
      }
      #${ROOT_ID} .category-button.is-dragging {
        opacity: 0.55;
        cursor: grabbing;
      }
      #${ROOT_ID} .category-add-button {
        border-style: dashed;
        color: var(--panel-blue);
        background: #f8fafc;
      }
      #${ROOT_ID} .collect-row {
        display: grid;
        grid-template-columns: auto 1fr;
        align-items: center;
        gap: 10px;
      }
      #${ROOT_ID} .speed-controls {
        grid-column: 1 / -1;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
      }
      #${ROOT_ID} .speed-field { display: grid; gap: 4px; }
      #${ROOT_ID} .speed-field label { font-size: 12px; color: #64748b; }
      #${ROOT_ID} .speed-input {
        width: 100%;
        height: 30px;
        padding: 0 8px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        color: #0f172a;
        background: #fff;
        font-size: 13px;
      }
      #${ROOT_ID} .speed-input:disabled {
        color: #94a3b8;
        background: #f1f5f9;
        cursor: not-allowed;
      }
      #${ROOT_ID} .collect-button, #${ROOT_ID} .copy-button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        flex: 0 0 auto;
        height: 34px;
        border: 1px solid var(--panel-text);
        border-radius: 999px;
        background: var(--panel-text);
        color: #fff;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
      }
      #${ROOT_ID} .collect-button { min-width: 92px; padding: 0 14px; }
      #${ROOT_ID} .collect-button.is-running { border-color: #dc2626; background: #dc2626; }
      #${ROOT_ID} .collect-status {
        min-width: 0;
        color: #64748b;
        font-size: 12px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }
      #${ROOT_ID} .response-card { min-height: 220px; }
      #${ROOT_ID} .copy-button {
        min-width: 58px;
        padding: 0 10px;
        border-color: #0f172a;
        background: #0f172a;
      }
      #${ROOT_ID} .copy-button:disabled {
        border-color: #cbd5e1;
        background: #e2e8f0;
        color: #94a3b8;
        cursor: not-allowed;
      }
      #${ROOT_ID} .response-body {
        padding: 10px 12px 12px;
        max-height: min(40vh, 420px);
        overflow: auto;
      }
      #${ROOT_ID} .monitor-meta {
        margin-bottom: 8px;
        font-size: 12px;
        line-height: 1.5;
        color: #475569;
        word-break: break-all;
      }
      #${ROOT_ID} .request-payload {
        margin-bottom: 8px;
        padding: 8px;
        color: #334155;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
      }
      #${ROOT_ID} .request-payload-title {
        margin-bottom: 6px;
        font-size: 12px;
        font-weight: 700;
        color: #0f172a;
      }
      #${ROOT_ID} .request-payload pre {
        min-height: 0;
        max-height: 130px;
        background: #ffffff;
        color: #0f172a;
        border-color: #e2e8f0;
      }
      #${ROOT_ID} pre {
        margin: 0;
        padding: 10px;
        min-height: 120px;
        overflow: auto;
        white-space: pre-wrap;
        word-break: break-word;
        font-size: 12px;
        line-height: 1.45;
        color: #e2e8f0;
        background: #0f172a;
        border: 1px solid rgba(15, 23, 42, 0.18);
        border-radius: 8px;
      }
      #${ROOT_ID} .monitor-empty {
        padding: 10px;
        font-size: 12px;
        color: #64748b;
        background: #f8fafc;
        border: 1px dashed #cbd5e1;
        border-radius: 8px;
      }
      #${ROOT_ID} .category-modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: grid;
        place-items: center;
        padding: 24px;
        background: rgba(17, 24, 39, 0.36);
        backdrop-filter: blur(8px);
      }
      #${ROOT_ID} .category-modal {
        width: min(420px, calc(100vw - 48px));
        padding: 18px;
        overflow: hidden;
        border: 1px solid rgba(17, 24, 39, 0.1);
        border-radius: 20px;
        background: #ffffff;
        box-shadow: 0 30px 90px rgba(15, 23, 42, 0.22), 0 2px 12px rgba(15, 23, 42, 0.08);
      }
      #${ROOT_ID} .auth-modal { padding: 0; }
      #${ROOT_ID} .auth-modal-head {
        display: grid;
        gap: 10px;
        padding: 22px 22px 14px;
        color: var(--panel-text);
        background: #ffffff;
      }
      #${ROOT_ID} .auth-modal-kicker {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border: 1px solid rgba(17, 24, 39, 0.08);
        border-radius: 14px;
        font-size: 12px;
        background: #f8fafc;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.9);
      }
      #${ROOT_ID} .modal-headline {
        display: grid;
        grid-template-columns: 40px minmax(0, 1fr);
        gap: 12px;
        align-items: start;
        margin-bottom: 16px;
      }
      #${ROOT_ID} .category-modal h2 {
        margin: 0;
        font-size: 18px;
        line-height: 1.3;
        color: inherit;
      }
      #${ROOT_ID} .auth-modal-body {
        padding: 4px 22px 22px;
      }
      #${ROOT_ID} .auth-hint {
        margin: -4px 0 12px;
        color: var(--panel-muted);
        font-size: 12px;
        line-height: 1.5;
      }
      #${ROOT_ID} .category-form-field {
        display: grid;
        gap: 5px;
        margin-bottom: 10px;
      }
      #${ROOT_ID} .category-form-field label { font-size: 12px; color: #475569; }
      #${ROOT_ID} .category-form-field input {
        width: 100%;
        height: 40px;
        padding: 0 11px;
        border: 1px solid rgba(17, 24, 39, 0.12);
        border-radius: 12px;
        font-size: 13px;
        outline: none;
        background: #f9fafb;
      }
      #${ROOT_ID} .category-form-field input:focus {
        border-color: #2563eb;
        box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
      }
      #${ROOT_ID} .auth-error {
        min-height: 18px;
        margin: 2px 0 0;
        color: #dc2626;
      }
      #${ROOT_ID} .category-modal-actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        margin-top: 12px;
      }
      #${ROOT_ID} .modal-button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        height: 36px;
        padding: 0 14px;
        border: 1px solid rgba(17, 24, 39, 0.12);
        border-radius: 999px;
        background: #ffffff;
        color: var(--panel-text);
        font-size: 13px;
        cursor: pointer;
      }
      #${ROOT_ID} .modal-button.primary { border-color: var(--panel-text); background: var(--panel-text); color: #ffffff; }
      #${ROOT_ID} .modal-button.danger { border-color: #dc2626; color: #dc2626; }
      #${TOAST_ID} {
        position: fixed;
        right: 24px;
        bottom: 24px;
        z-index: 2147483647;
        display: flex;
        flex-direction: column;
        gap: 10px;
        width: min(360px, calc(100vw - 32px));
        pointer-events: none;
        font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      }
      #${TOAST_ID} .monitor-toast {
        display: grid;
        grid-template-columns: 10px minmax(0, 1fr);
        align-items: start;
        gap: 12px;
        min-height: 48px;
        padding: 14px 16px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        border-radius: 18px;
        color: #111827;
        background: rgba(255, 255, 255, 0.94);
        box-shadow: 0 20px 60px rgba(15, 23, 42, 0.16), 0 1px 3px rgba(15, 23, 42, 0.08);
        backdrop-filter: blur(18px) saturate(1.2);
        animation: buyin-toast-in 180ms ease both;
      }
      #${TOAST_ID} .monitor-toast:nth-last-child(1) { opacity: 1; transform: translateY(0) scale(1); }
      #${TOAST_ID} .monitor-toast:nth-last-child(2) { opacity: 0.74; transform: translateY(-2px) scale(0.985); }
      #${TOAST_ID} .monitor-toast:nth-last-child(3) { opacity: 0.5; transform: translateY(-4px) scale(0.97); }
      #${TOAST_ID} .monitor-toast.is-leaving { animation: buyin-toast-out 180ms ease both; }
      #${TOAST_ID} .toast-dot {
        width: 9px;
        height: 9px;
        margin-top: 5px;
        border-radius: 999px;
        background: #2563eb;
        box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.14);
      }
      #${TOAST_ID} .monitor-toast.success .toast-dot { background: #0f8a5f; box-shadow: 0 0 0 4px rgba(15, 138, 95, 0.14); }
      #${TOAST_ID} .monitor-toast.warning .toast-dot { background: #b45309; box-shadow: 0 0 0 4px rgba(180, 83, 9, 0.14); }
      #${TOAST_ID} .monitor-toast.error .toast-dot { background: #dc2626; box-shadow: 0 0 0 4px rgba(220, 38, 38, 0.14); }
      #${TOAST_ID} .toast-text { min-width: 0; font-size: 13px; line-height: 1.55; }
      @keyframes buyin-toast-in { from { opacity: 0; transform: translateY(10px) scale(0.98); } }
      @keyframes buyin-toast-out { to { opacity: 0; transform: translateY(8px) scale(0.98); } }
      @media (max-width: 520px) {
        #${ROOT_ID} { top: 10px; right: 16px; width: calc(100vw - 32px); }
        #${ROOT_ID} .metrics { grid-template-columns: 1fr; }
        #${TOAST_ID} { right: 16px; bottom: 16px; }
      }
    `;
    (document.documentElement || document.head).appendChild(style);
  }

  function mountWhenReady() {
    if (document.body) {
      mountRoot();
      return;
    }
    document.addEventListener('DOMContentLoaded', mountRoot, { once: true });
  }

  function mountRoot() {
    if (root || !document.body) return;
    root = document.createElement('aside');
    root.id = ROOT_ID;
    root.innerHTML = `
      <section class="monitor-card">
        <div class="monitor-card-header">
          <h1 class="monitor-title">${iconSvg('sparkles')}超级福袋采集面板</h1>
          <div class="monitor-status">等待请求</div>
        </div>
        <div class="account-strip">
          <button class="account-name" type="button" data-account-name>${iconSvg('user')}<span data-account-name-text>游客模式</span></button>
          <button class="auth-action" type="button" data-auth-action>${iconSvg('login')}<span data-auth-action-text>注册/登录</span></button>
        </div>
        <div class="monitor-section">
          <div class="metrics">
            <div class="metric">
              <div class="metric-label">奖品类目所属</div>
              <div class="metric-value" data-category>自动识别</div>
            </div>
            <div class="metric">
              <div class="metric-label">奖品数量</div>
              <div class="metric-value" data-count>0</div>
            </div>
          </div>
        </div>
        <div class="monitor-section">
          <div class="section-heading">
            <div class="section-title">奖品类目</div>
            <div class="category-actions">
              <button class="category-action" type="button" data-select-toggle>${iconSvg('check')}<span data-select-toggle-text>全选</span></button>
            </div>
          </div>
          <div class="category-grid" data-category-grid></div>
        </div>
        <div class="monitor-section">
          <div class="collect-row">
            <button class="collect-button" type="button" data-collect>${iconSvg('play')}<span data-collect-text>开始采集</span></button>
            <div class="collect-status" data-collect-status>点击后将自动滚动到页面底部并等待瀑布流加载。</div>
            <div class="speed-controls">
              <div class="speed-field">
                <label for="buyin-luckybag-min-interval">最小间隔(ms)</label>
                <input class="speed-input" id="buyin-luckybag-min-interval" data-min-interval type="number" min="500" step="100" value="${DEFAULT_MIN_INTERVAL}">
              </div>
              <div class="speed-field">
                <label for="buyin-luckybag-max-interval">最大间隔(ms)</label>
                <input class="speed-input" id="buyin-luckybag-max-interval" data-max-interval type="number" min="500" step="100" value="${DEFAULT_MAX_INTERVAL}">
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="monitor-card response-card">
        <div class="monitor-card-header">
          <h1 class="monitor-title">${iconSvg('code')}响应数据</h1>
          <button class="copy-button" type="button" data-copy disabled>${iconSvg('copy')}<span data-copy-text>复制</span></button>
        </div>
        <div class="response-body">
          <div class="monitor-meta" data-response-meta>Target: <code>${escapeHtml(monitorConfig.targetPath || DEFAULT_MONITOR_CONFIG.targetPath)}</code></div>
          <div class="request-payload" data-request-payload hidden>
            <div class="request-payload-title">请求载荷</div>
            <pre data-request-payload-text></pre>
          </div>
          <div class="monitor-empty" data-response-empty>暂无匹配响应数据。</div>
          <pre data-response-text hidden></pre>
        </div>
      </section>
    `;
    document.body.appendChild(root);

    accountNameEl = root.querySelector('[data-account-name]');
    authActionEl = root.querySelector('[data-auth-action]');
    statusEl = root.querySelector('.monitor-status');
    categoryEl = root.querySelector('[data-category]');
    countEl = root.querySelector('[data-count]');
    categoryGridEl = root.querySelector('[data-category-grid]');
    selectToggleButton = root.querySelector('[data-select-toggle]');
    collectButton = root.querySelector('[data-collect]');
    collectStatusEl = root.querySelector('[data-collect-status]');
    responseBodyEl = root.querySelector('[data-response-text]');
    responseMetaEl = root.querySelector('[data-response-meta]');
    copyButton = root.querySelector('[data-copy]');
    responseEmptyEl = root.querySelector('[data-response-empty]');
    minIntervalInput = root.querySelector('[data-min-interval]');
    maxIntervalInput = root.querySelector('[data-max-interval]');

    accountNameEl.addEventListener('click', openOptionsPage);
    authActionEl.addEventListener('click', onAuthActionClick);
    selectToggleButton.addEventListener('click', toggleCategorySelection);
    collectButton.addEventListener('click', toggleCollection);
    copyButton.addEventListener('click', copyResponse);
    renderAuthState();
    renderCategories();
    loadSharedState();
    watchSharedStorage();
    watchEndMarker();
  }

  function renderCategories() {
    if (!categoryGridEl) return;
    categoryGridEl.innerHTML = '';
    categories.forEach((item, index) => {
      const button = document.createElement('button');
      button.className = 'category-button';
      button.type = 'button';
      button.textContent = item.name;
      button.dataset.index = String(index);
      button.dataset.key = getCategoryKey(item);
      button.draggable = !isAllCategory(item, index);
      button.title = isAllCategory(item, index) ? '单击选中，双击编辑' : '单击选中，双击编辑，长按拖动排序';
      if (isAllCategory(item, index)) button.classList.add('is-locked');
      if (selectedCategoryKeys.has(getCategoryKey(item))) button.classList.add('is-selected');
      if (activeCategory && getCategoryKey(activeCategory) === getCategoryKey(item)) button.classList.add('is-active-collecting');
      button.addEventListener('click', onCategoryClick);
      button.addEventListener('dblclick', onCategoryDoubleClick);
      button.addEventListener('pointerdown', onCategoryPointerDown);
      button.addEventListener('pointerup', clearLongPressTimer);
      button.addEventListener('pointercancel', clearLongPressTimer);
      button.addEventListener('pointerleave', clearLongPressTimer);
      button.addEventListener('dragstart', onCategoryDragStart);
      button.addEventListener('dragover', onCategoryDragOver);
      button.addEventListener('drop', onCategoryDrop);
      button.addEventListener('dragend', onCategoryDragEnd);
      categoryGridEl.appendChild(button);
    });

    const addButton = document.createElement('button');
    addButton.className = 'category-add-button';
    addButton.type = 'button';
    addButton.innerHTML = `${iconSvg('plus')}<span>新增类目</span>`;
    addButton.addEventListener('click', () => openCategoryModal('create'));
    categoryGridEl.appendChild(addButton);
    updateSelectToggleButton();
  }

  function onCategoryClick(event) {
    if (Date.now() < suppressClickUntil) return;
    const item = categories[Number(event.currentTarget.dataset.index)];
    if (!item) return;
    window.clearTimeout(clickTimer);
    clickTimer = window.setTimeout(() => {
      const key = getCategoryKey(item);
      if (selectedCategoryKeys.has(key)) selectedCategoryKeys.delete(key);
      else selectedCategoryKeys.add(key);
      renderCategories();
    }, 220);
  }

  function onCategoryDoubleClick(event) {
    event.preventDefault();
    event.stopPropagation();
    window.clearTimeout(clickTimer);
    clickTimer = 0;
    const index = Number(event.currentTarget.dataset.index);
    if (Number.isInteger(index)) openCategoryModal('edit', index);
  }

  function onCategoryPointerDown(event) {
    if (event.button !== 0) return;
    const button = event.currentTarget;
    const index = Number(button.dataset.index);
    if (isAllCategory(categories[index], index)) return;
    clearLongPressTimer();
    longPressTimer = window.setTimeout(() => {
      suppressClickUntil = Date.now() + 650;
      dragState = { fromIndex: Number(button.dataset.index) };
      button.draggable = true;
      button.classList.add('is-dragging');
      collectStatusEl.textContent = '已进入类目拖动排序状态，按住类目拖到目标位置后松开。';
    }, LONG_PRESS_MS);
  }

  function clearLongPressTimer() {
    window.clearTimeout(longPressTimer);
    longPressTimer = 0;
  }

  function onCategoryDragStart(event) {
    const index = Number(event.currentTarget.dataset.index);
    if (isAllCategory(categories[index], index)) {
      event.preventDefault();
      return;
    }
    if (!dragState) {
      event.preventDefault();
      return;
    }
    dragState.fromIndex = index;
    event.currentTarget.classList.add('is-dragging');
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('text/plain', String(index));
    }
  }

  function onCategoryDragOver(event) {
    if (!dragState) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
  }

  function onCategoryDrop(event) {
    if (!dragState) return;
    event.preventDefault();
    const fromIndex = dragState.fromIndex;
    const toIndex = Number(event.currentTarget.dataset.index);
    if (Number.isInteger(fromIndex) && Number.isInteger(toIndex) && fromIndex !== toIndex && fromIndex > 0) {
      const [item] = categories.splice(fromIndex, 1);
      categories.splice(Math.max(1, toIndex), 0, item);
      normalizeCategoriesInPlace();
      saveCategories();
      collectStatusEl.textContent = '类目顺序已更新，采集会按当前顺序执行。';
      showToast('类目顺序已更新。', 'success');
    }
    finishDrag();
  }

  function onCategoryDragEnd() {
    finishDrag();
  }

  function finishDrag() {
    dragState = null;
    suppressClickUntil = Date.now() + 450;
    renderCategories();
  }

  function toggleCategorySelection() {
    if (areAllCategoriesSelected()) {
      categories.forEach((item) => selectedCategoryKeys.delete(getCategoryKey(item)));
    } else {
      categories.forEach((item) => selectedCategoryKeys.add(getCategoryKey(item)));
    }
    renderCategories();
  }

  function updateSelectToggleButton() {
    if (!selectToggleButton) return;
    setButtonLabel(selectToggleButton, 'data-select-toggle-text', areAllCategoriesSelected() ? '反选' : '全选');
  }

  function areAllCategoriesSelected() {
    return categories.length > 0 && categories.every((item) => selectedCategoryKeys.has(getCategoryKey(item)));
  }

  function openCategoryModal(mode, index) {
    const editing = mode === 'edit';
    const original = editing ? categories[index] : { name: '新类目', value: '200' };
    if (!original) return;
    const editingAll = editing && isAllCategory(original, index);

    const backdrop = document.createElement('div');
    backdrop.className = 'category-modal-backdrop';
    backdrop.innerHTML = `
      <div class="category-modal" role="dialog" aria-modal="true">
        <div class="modal-headline">
          <span class="auth-modal-kicker">${iconSvg(editing ? 'edit' : 'plus')}</span>
          <div>
            <h2>${editing ? '编辑类目' : '新增类目'}</h2>
            <p class="auth-hint">类目 ID 会用于匹配请求载荷中的 BusinessCid。</p>
          </div>
        </div>
        <div class="category-form-field">
          <label>类目名称</label>
          <input data-modal-name type="text" value="${escapeHtml(original.name)}" maxlength="24">
        </div>
        <div class="category-form-field">
          <label>类目ID</label>
          <input data-modal-value type="text" value="${escapeHtml(original.value == null ? '' : original.value)}" placeholder="全部类目可留空" ${editingAll ? 'disabled' : ''}>
        </div>
        <div class="category-modal-actions">
          ${editing && !editingAll ? `<button class="modal-button danger" type="button" data-modal-delete>${iconSvg('trash')}删除类目</button>` : ''}
          <button class="modal-button primary" type="button" data-modal-save>${iconSvg('save')}${editing ? '更新类目' : '新增类目'}</button>
        </div>
      </div>
    `;
    root.appendChild(backdrop);
    const modal = backdrop.querySelector('.category-modal');
    const nameInput = backdrop.querySelector('[data-modal-name]');
    const valueInput = backdrop.querySelector('[data-modal-value]');
    nameInput.focus();
    nameInput.select();

    backdrop.addEventListener('click', (event) => {
      if (event.target === backdrop) backdrop.remove();
    });
    modal.addEventListener('click', (event) => event.stopPropagation());
    const deleteButton = backdrop.querySelector('[data-modal-delete]');
    if (deleteButton) {
      deleteButton.addEventListener('click', () => {
        const key = getCategoryKey(categories[index]);
        categories.splice(index, 1);
        selectedCategoryKeys.delete(key);
        normalizeCategoriesInPlace();
        saveCategories();
        renderCategories();
        backdrop.remove();
        showToast('类目已删除。', 'success');
      });
    }
    backdrop.querySelector('[data-modal-save]').addEventListener('click', () => {
      const name = nameInput.value.trim() || '新类目';
      const value = editingAll ? null : normalizeCategoryValue(valueInput.value);
      const next = { name, value };
      if (editing) {
        const oldKey = getCategoryKey(categories[index]);
        categories[index] = next;
        if (selectedCategoryKeys.delete(oldKey)) selectedCategoryKeys.add(getCategoryKey(next));
      } else {
        categories.push(next);
      }
      normalizeCategoriesInPlace();
      saveCategories();
      renderCategories();
      backdrop.remove();
      showToast(editing ? '类目信息已更新。' : '新类目已添加。', 'success');
    });
  }

  function renderAuthState() {
    if (!accountNameEl || !authActionEl) return;
    const loggedIn = isLoggedIn();
    const accountText = accountNameEl.querySelector('[data-account-name-text]');
    const authText = authActionEl.querySelector('[data-auth-action-text]');
    if (accountText) accountText.textContent = loggedIn ? authState.username : '游客模式';
    accountNameEl.title = '打开扩展程序选项';
    if (authText) authText.textContent = loggedIn ? '登出' : '注册/登录';
  }

  function onAuthActionClick() {
    if (isLoggedIn()) {
      logout();
      return;
    }
    openAuthModal('login');
  }

  function openOptionsPage() {
    const runtime = getRuntime();
    if (runtime && typeof runtime.sendMessage === 'function') {
      sendRuntimeMessage({ source: 'buyin-luckybag-monitor', type: 'open-options-page' });
      return;
    }
  }

  function openAuthModal(mode) {
    let currentMode = mode === 'register' ? 'register' : 'login';
    const backdrop = document.createElement('div');
    backdrop.className = 'category-modal-backdrop';
    const render = () => {
      const isRegister = currentMode === 'register';
      backdrop.innerHTML = `
        <div class="category-modal auth-modal" role="dialog" aria-modal="true">
          <div class="auth-modal-head">
            <span class="auth-modal-kicker">${iconSvg(isRegister ? 'userPlus' : 'lock')}</span>
            <h2>${isRegister ? '注册账号' : '登录账号'}</h2>
            <p class="auth-hint">登录后会按账号独立保存类目、接口和请求载荷配置。</p>
          </div>
          <div class="auth-modal-body">
            <div class="category-form-field">
              <label>账号</label>
              <input data-auth-username type="text" autocomplete="username" maxlength="32" placeholder="请输入账号">
            </div>
            <div class="category-form-field">
              <label>密码</label>
              <input data-auth-password type="password" autocomplete="${isRegister ? 'new-password' : 'current-password'}" maxlength="64" placeholder="请输入密码">
            </div>
            <div class="auth-error" data-auth-error></div>
            <div class="category-modal-actions">
              <button class="modal-button" type="button" data-auth-switch>${iconSvg(isRegister ? 'login' : 'userPlus')}${isRegister ? '返回登录' : '注册'}</button>
              <button class="modal-button primary" type="button" data-auth-submit>${iconSvg(isRegister ? 'check' : 'login')}${isRegister ? '注册并登录' : '登录'}</button>
            </div>
          </div>
        </div>
      `;
      const modal = backdrop.querySelector('.category-modal');
      const usernameInput = backdrop.querySelector('[data-auth-username]');
      const passwordInput = backdrop.querySelector('[data-auth-password]');
      const errorEl = backdrop.querySelector('[data-auth-error]');
      modal.addEventListener('click', (event) => event.stopPropagation());
      backdrop.querySelector('[data-auth-switch]').addEventListener('click', () => {
        currentMode = isRegister ? 'login' : 'register';
        render();
      });
      backdrop.querySelector('[data-auth-submit]').addEventListener('click', async () => {
        const username = usernameInput.value.trim();
        const password = passwordInput.value;
        const result = isRegister ? await registerUser(username, password) : await loginUser(username, password);
        if (!result.ok) {
          errorEl.textContent = result.message;
          showToast(result.message, 'error');
          return;
        }
        backdrop.remove();
      });
      usernameInput.focus();
    };
    backdrop.addEventListener('click', (event) => {
      if (event.target === backdrop) backdrop.remove();
    });
    render();
    root.appendChild(backdrop);
  }

  async function registerUser(username, password) {
    if (!username || !password) return { ok: false, message: '账号和密码不能为空。' };
    const currentCategories = normalizeCategoryList(categories);
    const users = await storageGet(STORAGE_KEYS.users, {});
    const userSettings = await storageGet(STORAGE_KEYS.userSettings, {});
    if (users[username]) return { ok: false, message: '该账号已存在，请直接登录。' };
    users[username] = { passwordHash: await hashText(password), createdAt: Date.now() };
    userSettings[username] = normalizeUserSettings({ categories: currentCategories, monitorConfig });
    authState = { mode: 'user', username };
    categories = currentCategories;
    await storageSet({ [STORAGE_KEYS.users]: users, [STORAGE_KEYS.userSettings]: userSettings, [STORAGE_KEYS.auth]: authState });
    renderAuthState();
    renderCategories();
    showToast(`账号「${username}」注册成功，已自动登录。`, 'success');
    return { ok: true };
  }

  async function loginUser(username, password) {
    if (!username || !password) return { ok: false, message: '账号和密码不能为空。' };
    const users = await storageGet(STORAGE_KEYS.users, {});
    const user = users[username];
    if (!user || user.passwordHash !== await hashText(password)) return { ok: false, message: '账号或密码不正确。' };
    await setAuthState({ mode: 'user', username });
    showToast(`欢迎回来，${username}。`, 'success');
    return { ok: true };
  }

  async function logout() {
    await setAuthState({ mode: 'guest', username: '' });
    showToast('已登出，当前为游客模式。', 'info');
  }

  async function setAuthState(nextState) {
    authState = nextState;
    if (isLoggedIn()) {
      const settings = await loadCurrentUserSettings();
      categories = settings.categories;
      monitorConfig = settings.monitorConfig;
    } else {
      categories = normalizeCategoryList(DEFAULT_CATEGORIES.slice());
      monitorConfig = normalizeMonitorConfig(DEFAULT_MONITOR_CONFIG);
      selectedCategoryKeys = new Set();
    }
    await storageSet({ [STORAGE_KEYS.auth]: authState });
    renderAuthState();
    renderCategories();
    updateMonitorConfigInPage();
  }

  function renderPayload(payload) {
    lastPayload = payload;
    const metaParts = [];
    if (payload.url) metaParts.push(`URL: ${payload.url}`);
    if (payload.method) metaParts.push(`Method: ${payload.method}`);
    if (typeof payload.status === 'number') metaParts.push(`Status: ${payload.status}`);
    if (payload.type) metaParts.push(`Type: ${payload.type}`);

    const responseText = formatBody(payload.body);
    const requestPayloadText = formatBody(payload.requestPayload || {});
    lastResponseText = responseText;

    statusEl.textContent = '已捕获';
    responseMetaEl.textContent = metaParts.join(' | ');
    renderRequestPayload(requestPayloadText);
    responseBodyEl.textContent = responseText;
    responseBodyEl.hidden = false;
    responseEmptyEl.hidden = true;
    copyButton.disabled = false;
    setButtonLabel(copyButton, 'data-copy-text', '复制');

    const payloadCategoryValue = getCategoryValueFromPayload(payload.requestPayload);
    categoryEl.textContent = identifyCategoryByValue(payloadCategoryValue);
    countEl.textContent = String(countPromotions(payload.body));

    if (collecting) {
      persistCollectedPromotions(payload.body, payloadCategoryValue);
      handleCollectionPayload(payloadCategoryValue);
    }
  }

  async function persistCollectedPromotions(body, categoryValue) {
    const promotions = body && body.data ? body.data.summary_promotions : null;
    const items = Array.isArray(promotions) ? promotions : promotions && typeof promotions === 'object' ? Object.values(promotions) : [];
    const validItems = items.filter((item) => item && item.product_id);
    if (!validItems.length) return;
    prizeLibraryWriteQueue = prizeLibraryWriteQueue.then(async () => {
      const library = await storageGet(STORAGE_KEYS.prizeLibrary, {});
      const nextLibrary = library && typeof library === 'object' ? library : {};
      const categoryName = identifyCategoryByValue(categoryValue);
      const updatedAt = new Date().toISOString();
      validItems.forEach((item) => {
      const productInfo = item.base_model && item.base_model.product_info ? item.base_model.product_info : {};
      const marketingInfo = item.base_model && item.base_model.marketing_info ? item.base_model.marketing_info : {};
      const priceDesc = marketingInfo.price_desc || {};
      const shopInfo = item.base_model && item.base_model.shop_info ? item.base_model.shop_info : {};
      const tagInfo = item.base_model && item.base_model.tag_info ? item.base_model.tag_info : {};
      const tags = [];
      if (Array.isArray(tagInfo.main_tags) && tagInfo.main_tags.some((tag) => tag && tag.type === 'aweme_flagship')) tags.push('抖音旗舰');
      if (Array.isArray(tagInfo.second_tags)) {
        tagInfo.second_tags.forEach((tag) => {
          const text = tag && tag.text && tag.text.text;
          if (text && !tags.includes(text)) tags.push(text);
        });
      }
      const id = String(item.product_id);
      const previous = nextLibrary[id] || {};
      const createdAt = previous.createdAt || updatedAt;
      const previousCategories = Array.isArray(previous.categories) ? previous.categories : [];
      const nextCategories = previousCategories.includes('全部') ? previousCategories.slice() : ['全部'].concat(previousCategories);
      if (categoryName && categoryName !== '未知类目' && !nextCategories.includes(categoryName)) nextCategories.push(categoryName);
      nextLibrary[id] = {
        ...previous,
        id,
        name: String(productInfo.name || previous.name || '未命名奖品'),
        image: (productInfo.main_img && Array.isArray(productInfo.main_img.url_list) && productInfo.main_img.url_list[0]) || previous.image || '',
        monthSale: numberOrNull(productInfo.month_sale && productInfo.month_sale.origin, previous.monthSale),
        regularPrice: centsToPrice(priceDesc.regular_price && priceDesc.regular_price.origin, previous.regularPrice),
        price: centsToPrice(priceDesc.price && priceDesc.price.origin, previous.price),
        shopId: String(shopInfo.shop_id || previous.shopId || ''),
        shopName: String(shopInfo.shop_name || previous.shopName || '未知店铺'),
        shopScore: numberOrNull(shopInfo.shop_score_info && shopInfo.shop_score_info.shop_score && shopInfo.shop_score_info.shop_score.score, previous.shopScore),
        shopLogo: (shopInfo.shop_logo && Array.isArray(shopInfo.shop_logo.url_list) && shopInfo.shop_logo.url_list[0]) || previous.shopLogo || '',
        tags: tags.length ? tags : (previous.tags || []),
        categories: nextCategories,
        createdAt,
        updatedAt,
      };
      });
      await storageSet({ [STORAGE_KEYS.prizeLibrary]: nextLibrary });
    }).catch(() => undefined);
    await prizeLibraryWriteQueue;
  }

  async function persistLatestKnownPayload() {
    if (!lastPayload || !lastPayload.body) return;
    await persistCollectedPromotions(lastPayload.body, getCategoryValueFromPayload(lastPayload.requestPayload));
  }

  function numberOrNull(value, fallback = null) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function centsToPrice(value, fallback = null) {
    const number = Number(value);
    return Number.isFinite(number) ? number / 100 : fallback;
  }

  function handleCollectionPayload(payloadCategoryValue) {
    if (!activeCategory) {
      collectStatusEl.textContent = '已捕获新数据，继续等待下一批加载。';
      return;
    }
    if (categoryValuesEqual(payloadCategoryValue, activeCategory.value)) {
      waitingForCategoryPayload = false;
      collectStatusEl.textContent = `已捕获「${activeCategory.name}」数据，继续等待下一批加载。`;
      return;
    }
    if (!switchingCategory && Date.now() >= ignoreEndUntil) {
      stopCollection(`当前请求类目与「${activeCategory.name}」不一致，已停止采集。`);
      return;
    }
    collectStatusEl.textContent = `当前请求类目与「${activeCategory.name}」不一致，等待目标类目请求后继续采集。`;
  }

  function identifyCategoryByValue(value) {
    const match = categories.find((item) => categoryValuesEqual(item.value, value));
    return match ? match.name : '未知类目';
  }

  function getCategoryValueFromPayload(requestPayload) {
    if (matchesPayloadTemplate(monitorConfig.allRequestTemplate, requestPayload)) return null;
    const templateValue = getCategoryValueFromTemplatePath(requestPayload);
    if (templateValue !== undefined) return templateValue;
    return '';
  }

  function matchesPayloadTemplate(template, payload) {
    if (!template || typeof template !== 'object' || Array.isArray(template)) return false;
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false;
    return isTemplateSubset(template, payload);
  }

  function isTemplateSubset(template, payload) {
    if (template === '__CATEGORY_ID__') return payload != null && String(payload).trim() !== '';
    if (Array.isArray(template)) {
      if (!Array.isArray(payload) || template.length !== payload.length) return false;
      return template.every((item, index) => isTemplateSubset(item, payload[index]));
    }
    if (template && typeof template === 'object') {
      if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return false;
      const keys = Object.keys(template);
      if (keys.length === 0) return Object.keys(payload).length === 0;
      return keys.every((key) => Object.prototype.hasOwnProperty.call(payload, key) && isTemplateSubset(template[key], payload[key]));
    }
    return Object.is(template, payload);
  }

  function getCategoryValueFromTemplatePath(requestPayload) {
    if (!requestPayload || typeof requestPayload !== 'object') return undefined;
    const template = monitorConfig.categoryRequestTemplate || monitorConfig.requestTemplate;
    const paths = findCategoryPlaceholderPaths(template);
    if (!paths.length || !matchesPayloadTemplate(template, requestPayload)) return undefined;
    for (const path of paths) {
      const value = getValueByPath(requestPayload, path);
      const normalized = normalizeExtractedCategoryValue(value);
      if (normalized !== undefined) return normalized;
    }
    return undefined;
  }

  function findCategoryPlaceholderPaths(source) {
    const paths = [];
    const walk = (node, path) => {
      if (node === '__CATEGORY_ID__') {
        paths.push(path);
        return;
      }
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) {
        node.forEach((item, index) => walk(item, path.concat(index)));
        return;
      }
      Object.keys(node).forEach((key) => walk(node[key], path.concat(key)));
    };
    walk(source, []);
    return paths;
  }

  function getValueByPath(source, path) {
    return path.reduce((node, key) => (node == null ? undefined : node[key]), source);
  }

  function normalizeExtractedCategoryValue(value) {
    if (Array.isArray(value)) return value.length ? String(value[0]) : '';
    if (value == null) return undefined;
    const text = String(value).trim();
    return text ? text : '';
  }

  function countPromotions(body) {
    const promotions = body && body.data ? body.data.summary_promotions : null;
    if (Array.isArray(promotions)) return promotions.filter((item) => item && item.product_id).length;
    if (promotions && typeof promotions === 'object') {
      return Object.values(promotions).filter((item) => item && item.product_id).length;
    }
    return 0;
  }

  function formatBody(body) {
    return typeof body === 'string' ? body : JSON.stringify(body, null, 2);
  }

  function renderRequestPayload(text) {
    const wrapper = root.querySelector('[data-request-payload]');
    const payloadTextEl = root.querySelector('[data-request-payload-text]');
    if (!wrapper || !payloadTextEl) return;
    payloadTextEl.textContent = text || '{}';
    wrapper.hidden = false;
  }

  async function copyResponse() {
    if (!lastResponseText) return;
    try {
      await navigator.clipboard.writeText(lastResponseText);
      setButtonLabel(copyButton, 'data-copy-text', '已复制');
      showToast('响应数据已复制。', 'success');
    } catch (error) {
      const textarea = document.createElement('textarea');
      textarea.value = lastResponseText;
      textarea.style.position = 'fixed';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
      setButtonLabel(copyButton, 'data-copy-text', '已复制');
      showToast('响应数据已复制。', 'success');
    }
    window.setTimeout(() => {
      setButtonLabel(copyButton, 'data-copy-text', '复制');
    }, 1400);
  }

  function toggleCollection() {
    if (collecting) {
      stopCollection('已停止采集。');
      return;
    }
    startCollection();
  }

  function startCollection() {
    collecting = true;
    setButtonLabel(collectButton, 'data-collect-text', '停止采集');
    collectButton.classList.add('is-running');
    setSpeedInputsDisabled(true);
    const range = getIntervalRange();
    const selected = categories.filter((item) => selectedCategoryKeys.has(getCategoryKey(item)));
    collectionQueue = selected.slice();
    activeCategory = null;
    waitingForCategoryPayload = false;
    switchingCategory = false;
    advancingCategory = false;
    ignoredEndMarkers = new WeakSet();
    snapshotExistingEndMarkers();
    categoryScrollCount = 0;
    ignoreEndUntil = 0;
    lastScrollResult = null;
    nextDelay = 0;
    renderCategories();
    showToast('已开始自动采集。', 'info');

    if (lastPayload && lastPayload.body) {
      persistCollectedPromotions(lastPayload.body, getCategoryValueFromPayload(lastPayload.requestPayload));
    }

    requestPageCategoryFilterExpand();
    waitForCategoryFilterExpand().then((expanded) => {
      if (!collecting) return;
      if (!expanded) {
        stopCollection('奖品类目导航栏未能展开，已停止采集。');
        return;
      }
      if (collectionQueue.length > 0) {
        collectStatusEl.textContent = `采集中，已选择 ${collectionQueue.length} 个类目，随机间隔 ${range.min}-${range.max}ms。`;
        startNextCategory();
        return;
      }
      collectStatusEl.textContent = `采集中，未选择类目，将保持网页当前类目，随机间隔 ${range.min}-${range.max}ms。`;
      runCollectionStep();
    });
  }

  function stopCollection(message, options = {}) {
    const shouldScrollToBottom = Boolean(options.scrollToBottom);
    collecting = false;
    window.clearTimeout(collectTimer);
    collectTimer = 0;
    collectionQueue = [];
    activeCategory = null;
    waitingForCategoryPayload = false;
    switchingCategory = false;
    advancingCategory = false;
    ignoredEndMarkers = new WeakSet();
    categoryScrollCount = 0;
    ignoreEndUntil = 0;
    setButtonLabel(collectButton, 'data-collect-text', '开始采集');
    collectButton.classList.remove('is-running');
    setSpeedInputsDisabled(false);
    if (shouldScrollToBottom) requestPageScrollToBottom();
    persistLatestKnownPayload().catch(() => undefined);
    collectStatusEl.textContent = message;
    renderCategories();
    showToast(message, shouldScrollToBottom ? 'success' : 'info');
  }

  function startNextCategory() {
    if (!collecting) return;
    advancingCategory = false;
    const next = collectionQueue.shift();
    if (!next) {
      stopCollection('已完成全部选中类目采集。', { scrollToBottom: true });
      return;
    }
    activeCategory = next;
    waitingForCategoryPayload = true;
    switchingCategory = true;
    snapshotExistingEndMarkers();
    categoryScrollCount = 0;
    ignoreEndUntil = Date.now() + 2200;
    renderCategories();
    collectStatusEl.textContent = `正在切换到「${next.name}」类目。`;
    requestPageCategorySelect(next);
    window.clearTimeout(collectTimer);
    collectTimer = window.setTimeout(() => {
      switchingCategory = false;
      if (!collecting) return;
      if (waitingForCategoryPayload) {
        collectStatusEl.textContent = `已切换「${next.name}」，等待 material_list 请求载荷匹配后开始滚动。`;
      }
      runCollectionStep();
    }, Math.max(900, Math.min(getRandomInterval(), 1800)));
  }

  function finishCurrentCategoryAndContinue() {
    if (!collecting) return;
    if (advancingCategory) return;
    advancingCategory = true;
    requestPageScrollToBottom();
    const doneName = activeCategory ? activeCategory.name : '当前类目';
    window.clearTimeout(collectTimer);
    collectStatusEl.textContent = `检测到「${doneName}」没有更多了，正在切换下一个类目。`;
    window.setTimeout(startNextCategory, 900);
  }

  function runCollectionStep() {
    if (!collecting) return;
    if (Date.now() < ignoreEndUntil) {
      collectTimer = window.setTimeout(runCollectionStep, 500);
      return;
    }
    if (categoryScrollCount > 0 && hasEndMarker()) {
      if (activeCategory && collectionQueue.length > 0) {
        finishCurrentCategoryAndContinue();
      } else {
        stopCollection('检测到“没有更多了”，采集结束。', { scrollToBottom: true });
      }
      return;
    }
    if (activeCategory && waitingForCategoryPayload && !switchingCategory) {
      collectStatusEl.textContent = `等待「${activeCategory.name}」类目的 material_list 请求载荷匹配，暂不滚动。`;
      collectTimer = window.setTimeout(runCollectionStep, Math.min(getRandomInterval(), 1600));
      return;
    }
    requestPageScrollToBottom();
    categoryScrollCount += 1;
    nextDelay = getRandomInterval();
    const prefix = activeCategory ? `「${activeCategory.name}」` : '当前类目';
    collectStatusEl.textContent = `已发送${prefix}自动置底指令，等待页面滚动和瀑布流加载。下次间隔 ${nextDelay}ms。`;
    collectTimer = window.setTimeout(runCollectionStep, nextDelay);
  }

  function getIntervalRange() {
    const minValue = Number.parseInt(minIntervalInput.value, 10);
    const maxValue = Number.parseInt(maxIntervalInput.value, 10);
    let min = Number.isFinite(minValue) ? minValue : DEFAULT_MIN_INTERVAL;
    let max = Number.isFinite(maxValue) ? maxValue : DEFAULT_MAX_INTERVAL;
    min = Math.max(MIN_ALLOWED_INTERVAL, min);
    max = Math.max(MIN_ALLOWED_INTERVAL, max);
    if (min > max) [min, max] = [max, min];
    minIntervalInput.value = String(min);
    maxIntervalInput.value = String(max);
    return { min, max };
  }

  function getRandomInterval() {
    const range = getIntervalRange();
    return Math.floor(range.min + Math.random() * (range.max - range.min + 1));
  }

  function setSpeedInputsDisabled(disabled) {
    minIntervalInput.disabled = disabled;
    maxIntervalInput.disabled = disabled;
  }

  function requestPageScrollToBottom() {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-scroll-to-bottom',
      },
      '*'
    );
  }

  function requestPageCategorySelect(category) {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-select-category',
        payload: { name: category.name, value: category.value },
      },
      '*'
    );
  }

  function requestPageCategoryFilterExpand() {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-expand-category-filter',
      },
      '*'
    );
  }

  function waitForCategoryFilterExpand() {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const check = () => {
        const filter = document.querySelector('[data-react-components*="cate-filter"]');
        const buttonText = (filter && filter.querySelector('.index_module__expandButton___f6e8c button, .index_module__expandButton___f6e8c')?.textContent || '').trim();
        const className = String(filter && filter.className ? filter.className : '');
        const forced = Boolean(filter && filter.getAttribute('data-buyin-force-expanded') === 'true');
        const expanded = forced || buttonText.includes('收起') || (className.includes('expand') && !className.includes('notExpand') && !buttonText.includes('展开'));
        if (expanded) {
          resolve(true);
          return;
        }
        if (Date.now() - startedAt >= 4500) {
          resolve(false);
          return;
        }
        window.setTimeout(check, 80);
      };
      check();
    });
  }

  function renderScrollResult(result) {
    lastScrollResult = result;
    if (!collecting || !collectStatusEl) return;
    const changed = result.changedCount || 0;
    const total = result.containerCount || 0;
    const height = result.maxScrollHeight || 0;
    const first = result.containers && result.containers[0] ? result.containers[0].name : '未识别';
    const delayText = nextDelay ? `，下次间隔 ${nextDelay}ms` : '';
    const prefix = activeCategory ? `「${activeCategory.name}」` : '当前类目';
    collectStatusEl.textContent = `${prefix}已置底 ${changed}/${total} 个滚动容器，最大高度 ${height}，主容器：${first}${delayText}`;
  }

  function renderCategorySelectResult(result) {
    if (!collecting || !collectStatusEl || !activeCategory) return;
    switchingCategory = false;
    if (result && result.ok) {
      const fallback = result.fallback || {};
      if (fallback.mode === 'fallback-fetch') {
        collectStatusEl.textContent = `已切换网页「${activeCategory.name}」类目，页面未自动加载，已补发 material_list 请求。`;
      } else {
        collectStatusEl.textContent = `已切换网页「${activeCategory.name}」类目，等待接口请求确认。`;
      }
      return;
    }
    stopCollection(`无法切换到「${activeCategory.name}」类目：${result && result.reason ? result.reason : '未找到网页类目按钮'}。`);
  }

  function showToast(message, type = 'info') {
    if (!document.body) return;
    if (!toastRoot) {
      toastRoot = document.getElementById(TOAST_ID);
      if (!toastRoot) {
        toastRoot = document.createElement('div');
        toastRoot.id = TOAST_ID;
        toastRoot.setAttribute('aria-live', 'polite');
        document.body.appendChild(toastRoot);
      }
    }
    const toast = document.createElement('div');
    toast.className = `monitor-toast ${type}`;
    const dot = document.createElement('span');
    dot.className = 'toast-dot';
    const text = document.createElement('span');
    text.className = 'toast-text';
    text.textContent = message;
    toast.append(dot, text);
    toastRoot.appendChild(toast);
    while (toastRoot.children.length > 3) toastRoot.firstElementChild.remove();
    window.setTimeout(() => {
      toast.classList.add('is-leaving');
      window.setTimeout(() => toast.remove(), 180);
    }, 3000);
  }

  function hasEndMarker() {
    const nodes = getEndMarkerNodes();
    return nodes.some((node) => {
      if (node.closest && node.closest(`#${ROOT_ID}`)) return false;
      if (ignoredEndMarkers.has(node)) return false;
      return (node.textContent || '').trim() === END_TEXT;
    });
  }

  function snapshotExistingEndMarkers() {
    ignoredEndMarkers = new WeakSet(getEndMarkerNodes().filter((node) => {
      if (node.closest && node.closest(`#${ROOT_ID}`)) return false;
      return (node.textContent || '').trim() === END_TEXT;
    }));
  }

  function getEndMarkerNodes() {
    return Array.from(document.querySelectorAll('.sp-infinit-end, [elementtiming="element-timing"]'));
  }

  function watchEndMarker() {
    if (endObserver) return;
    endObserver = new MutationObserver(() => {
      if (Date.now() < ignoreEndUntil) return;
      if (!collecting || categoryScrollCount <= 0 || !hasEndMarker()) return;
      if (activeCategory && collectionQueue.length > 0) {
        finishCurrentCategoryAndContinue();
      } else {
        stopCollection('检测到“没有更多了”，采集结束。', { scrollToBottom: true });
      }
    });
    endObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  async function loadSharedState() {
    authState = await storageGet(STORAGE_KEYS.auth, { mode: 'guest', username: '' });
    const settings = isLoggedIn() ? await loadCurrentUserSettings() : normalizeUserSettings();
    monitorConfig = settings.monitorConfig;
    categories = settings.categories;
    renderAuthState();
    renderCategories();
    updateMonitorConfigInPage();
    if (responseMetaEl) responseMetaEl.innerHTML = `Target: <code>${escapeHtml(monitorConfig.targetPath)}</code>`;
  }

  async function loadCategories() {
    return (await loadCurrentUserSettings()).categories;
  }

  async function saveCategories() {
    normalizeCategoriesInPlace();
    if (!isLoggedIn()) return;
    await saveCurrentUserSettings({ categories });
  }

  async function loadCurrentUserSettings() {
    if (!isLoggedIn()) return normalizeUserSettings();
    const userSettings = await storageGet(STORAGE_KEYS.userSettings, {});
    const existing = userSettings && typeof userSettings === 'object' ? userSettings[authState.username] : null;
    if (existing) return normalizeUserSettings(existing);
    const legacyCategories = await storageGet(STORAGE_KEYS.categories, null);
    const legacyMonitorConfig = await storageGet(STORAGE_KEYS.monitorConfig, null);
    const migrated = normalizeUserSettings({
      categories: Array.isArray(legacyCategories) ? legacyCategories : DEFAULT_CATEGORIES.slice(),
      monitorConfig: legacyMonitorConfig || DEFAULT_MONITOR_CONFIG,
    });
    await saveCurrentUserSettings(migrated);
    return migrated;
  }

  async function saveCurrentUserSettings(patch) {
    if (!isLoggedIn()) return;
    const userSettings = await storageGet(STORAGE_KEYS.userSettings, {});
    const current = normalizeUserSettings(userSettings[authState.username]);
    userSettings[authState.username] = normalizeUserSettings(Object.assign({}, current, patch));
    await storageSet({ [STORAGE_KEYS.userSettings]: userSettings });
  }

  function updateMonitorConfigInPage() {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-update-config',
        payload: monitorConfig,
      },
      '*'
    );
  }

  function watchSharedStorage() {
    const api = typeof browser !== 'undefined' && browser.storage ? browser.storage : typeof chrome !== 'undefined' && chrome.storage ? chrome.storage : null;
    if (!api || !api.onChanged || watchSharedStorage.active) return;
    watchSharedStorage.active = true;
    api.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local') return;
      if (changes[STORAGE_KEYS.auth]) {
        authState = changes[STORAGE_KEYS.auth].newValue || { mode: 'guest', username: '' };
        loadSharedState();
        return;
      }
      if (changes[STORAGE_KEYS.userSettings]) {
        if (isLoggedIn()) {
          const nextSettings = normalizeUserSettings((changes[STORAGE_KEYS.userSettings].newValue || {})[authState.username]);
          categories = nextSettings.categories;
          monitorConfig = nextSettings.monitorConfig;
        } else {
          categories = normalizeCategoryList(DEFAULT_CATEGORIES.slice());
          monitorConfig = normalizeMonitorConfig(DEFAULT_MONITOR_CONFIG);
        }
        selectedCategoryKeys = new Set(Array.from(selectedCategoryKeys).filter((key) => categories.some((item) => getCategoryKey(item) === key)));
        renderCategories();
        updateMonitorConfigInPage();
        if (responseMetaEl) responseMetaEl.innerHTML = `Target: <code>${escapeHtml(monitorConfig.targetPath)}</code>`;
      }
    });
  }

  function normalizeMonitorConfig(config) {
    const source = config && typeof config === 'object' ? config : DEFAULT_MONITOR_CONFIG;
    const legacyTemplate = source.requestTemplate && typeof source.requestTemplate === 'object' ? source.requestTemplate : null;
    const allRequestTemplate = source.allRequestTemplate && typeof source.allRequestTemplate === 'object' ? source.allRequestTemplate : cloneJson(DEFAULT_MONITOR_CONFIG.allRequestTemplate);
    const categoryRequestTemplate = source.categoryRequestTemplate && typeof source.categoryRequestTemplate === 'object' ? source.categoryRequestTemplate : legacyTemplate || cloneJson(DEFAULT_MONITOR_CONFIG.categoryRequestTemplate);
    return {
      targetPath: String(source.targetPath || DEFAULT_MONITOR_CONFIG.targetPath).trim() || DEFAULT_MONITOR_CONFIG.targetPath,
      allRequestTemplate,
      categoryRequestTemplate,
      requestTemplate: categoryRequestTemplate,
    };
  }

  function normalizeUserSettings(settings) {
    const source = settings && typeof settings === 'object' ? settings : {};
    return {
      categories: normalizeCategoryList(Array.isArray(source.categories) ? source.categories : DEFAULT_CATEGORIES.slice()),
      monitorConfig: normalizeMonitorConfig(source.monitorConfig || DEFAULT_MONITOR_CONFIG),
    };
  }

  function isLoggedIn() {
    return authState && authState.mode === 'user' && Boolean(authState.username);
  }

  function getRuntime() {
    return typeof browser !== 'undefined' && browser.runtime ? browser.runtime : typeof chrome !== 'undefined' && chrome.runtime ? chrome.runtime : null;
  }

  function sendRuntimeMessage(message) {
    const runtime = getRuntime();
    if (!runtime || typeof runtime.sendMessage !== 'function') return;
    try {
      if (typeof browser !== 'undefined' && browser.runtime === runtime) {
        const result = runtime.sendMessage(message);
        if (result && typeof result.catch === 'function') result.catch(() => undefined);
        return;
      }
      runtime.sendMessage(message, () => void getLastRuntimeError());
    } catch (error) {
      try {
        const result = runtime.sendMessage(message);
        if (result && typeof result.catch === 'function') result.catch(() => undefined);
      } catch (retryError) {
        // Ignore message failures; the panel should keep working even if options cannot open.
      }
    }
  }

  function getLastRuntimeError() {
    const runtime = getRuntime();
    return runtime && runtime.lastError ? runtime.lastError : null;
  }

  function getStorageArea() {
    const runtime = getRuntime();
    const api = typeof browser !== 'undefined' && browser.storage ? browser.storage : typeof chrome !== 'undefined' && chrome.storage ? chrome.storage : null;
    return runtime && api && api.local ? api.local : null;
  }

  function storageGet(key, fallback) {
    const area = getStorageArea();
    if (!area) return Promise.resolve(fallback);
    if (typeof browser !== 'undefined' && browser.storage) {
      return area.get(key).then((result) => (Object.prototype.hasOwnProperty.call(result, key) ? result[key] : fallback)).catch(() => fallback);
    }
    return new Promise((resolve) => {
      area.get(key, (result) => resolve(result && Object.prototype.hasOwnProperty.call(result, key) ? result[key] : fallback));
    });
  }

  function storageSet(values) {
    const area = getStorageArea();
    if (!area) return Promise.resolve();
    if (typeof browser !== 'undefined' && browser.storage) return area.set(values).catch(() => undefined);
    return new Promise((resolve) => area.set(values, resolve));
  }

  async function hashText(text) {
    if (crypto && crypto.subtle) {
      const data = new TextEncoder().encode(text);
      const digest = await crypto.subtle.digest('SHA-256', data);
      return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, '0')).join('');
    }
    let hash = 0;
    for (let index = 0; index < text.length; index += 1) hash = ((hash << 5) - hash + text.charCodeAt(index)) | 0;
    return String(hash);
  }

  function cloneJson(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (error) {
      return value;
    }
  }

  function normalizeCategoriesInPlace() {
    categories = normalizeCategoryList(categories);
  }

  function normalizeCategoryList(list) {
    const source = Array.isArray(list) ? list : [];
    const allCategory = source.find((item) => isAllCategory(item)) || { name: '全部', value: null };
    const others = source.filter((item) => !isAllCategory(item));
    return [{ name: allCategory.name || '全部', value: null }].concat(others);
  }

  function isAllCategory(item, index) {
    if (!item) return false;
    if (index === 0 && normalizeCategoryValue(item.value) === null) return true;
    return normalizeCategoryValue(item.value) === null && String(item.name || '').trim() === '全部';
  }

  function normalizeCategoryValue(value) {
    const text = value == null ? '' : String(value).trim();
    return text ? text : null;
  }

  function getCategoryKey(item) {
    return `${item.value == null ? 'all' : item.value}::${item.name}`;
  }

  function categoryValuesEqual(left, right) {
    return normalizeCategoryValue(left) === normalizeCategoryValue(right);
  }

  function setButtonLabel(button, selectorName, text) {
    if (!button) return;
    const label = button.querySelector(`[${selectorName}]`);
    if (label) label.textContent = text;
    else button.textContent = text;
  }

  function iconSvg(name) {
    const icons = {
      sparkles: '<path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3Z"/><path d="M19 14l.8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8L19 14Z"/>',
      user: '<path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/>',
      login: '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/>',
      check: '<path d="M20 6 9 17l-5-5"/>',
      play: '<path d="M8 5v14l11-7-11-7Z"/>',
      code: '<path d="m16 18 6-6-6-6"/><path d="m8 6-6 6 6 6"/>',
      copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><rect x="2" y="2" width="13" height="13" rx="2"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/>',
      trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 16h10l1-16"/>',
      save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
      userPlus: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
      lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    };
    return `<svg class="mini-icon" aria-hidden="true" viewBox="0 0 24 24">${icons[name] || icons.sparkles}</svg>`;
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'buyin-luckybag-monitor') return;
    if (data.type === 'material_list-response') {
      if (!root) mountRoot();
      if (root) renderPayload(data.payload);
    }
    if (data.type === 'collection-scroll-result') {
      if (!root) mountRoot();
      if (root) renderScrollResult(data.payload || {});
    }
    if (data.type === 'collection-select-category-result') {
      if (!root) mountRoot();
      if (root) renderCategorySelectResult(data.payload || {});
    }
  });

  function injectPageHook() {
    const hook = document.createElement('script');
    const runtime = typeof browser !== 'undefined' ? browser.runtime : chrome.runtime;
    hook.src = runtime.getURL('page-hook.js');
    hook.async = false;
    (document.documentElement || document.head).appendChild(hook);
    hook.addEventListener('load', () => hook.remove(), { once: true });
  }
})();
