const extensionApi = typeof browser !== 'undefined' ? browser : typeof chrome !== 'undefined' ? chrome : null;
const runtime = extensionApi && extensionApi.runtime ? extensionApi.runtime : null;

function openOptionsPage() {
  if (!runtime) return;
  const fallback = () => {
    if (extensionApi.tabs && extensionApi.tabs.create && runtime.getURL) {
      extensionApi.tabs.create({ url: runtime.getURL('options.html') });
    }
  };
  try {
    if (runtime.openOptionsPage) {
      const result = runtime.openOptionsPage();
      if (result && typeof result.catch === 'function') result.catch(fallback);
      return;
    }
    fallback();
  } catch (error) {
    fallback();
  }
}

if (runtime && runtime.onMessage) {
  runtime.onMessage.addListener((message) => {
    if (!message || message.source !== 'buyin-luckybag-monitor' || message.type !== 'open-options-page') return false;
    openOptionsPage();
    return false;
  });
}
