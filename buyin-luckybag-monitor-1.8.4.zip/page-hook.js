(function () {
  const DEFAULT_TARGET_PATH = '/pc/selection/common/material_list';
  const RECORDED_EVENT_TYPES = new Set(['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup']);
  const POLICY_BLOCKED_EVENT_TYPES = new Set(['unload']);
  const FORCE_CATEGORY_EXPAND_STYLE_ID = 'buyin-luckybag-force-category-expand-style';
  const recordedEventListeners = [];
  let lastMaterialListTemplate = null;
  let lastMaterialListStartedAt = 0;
  let monitorConfig = {
    targetPath: DEFAULT_TARGET_PATH,
    allRequestTemplate: { filters: {} },
    categoryRequestTemplate: { filters: { BusinessCid: { value: ['__CATEGORY_ID__'] } } },
    requestTemplate: { filters: { BusinessCid: { value: ['__CATEGORY_ID__'] } } },
  };

  patchEventListenerRecorder();

  function patchEventListenerRecorder() {
    const proto = typeof EventTarget !== 'undefined' && EventTarget.prototype;
    if (!proto || proto.__buyinLuckybagListenerRecorder) return;
    const originalAddEventListener = proto.addEventListener;
    const originalRemoveEventListener = proto.removeEventListener;
    Object.defineProperty(proto, '__buyinLuckybagListenerRecorder', {
      value: true,
      configurable: true,
    });
    proto.addEventListener = function (type, listener, options) {
      const eventType = String(type || '').toLowerCase();
      if (POLICY_BLOCKED_EVENT_TYPES.has(eventType)) return undefined;
      if (RECORDED_EVENT_TYPES.has(eventType) && listener) {
        recordedEventListeners.push({ target: this, type, listener, options, removed: false });
      }
      return originalAddEventListener.apply(this, arguments);
    };
    proto.removeEventListener = function (type, listener, options) {
      const eventType = String(type || '').toLowerCase();
      if (POLICY_BLOCKED_EVENT_TYPES.has(eventType)) return undefined;
      if (RECORDED_EVENT_TYPES.has(eventType) && listener) {
        recordedEventListeners.forEach((record) => {
          if (record.target === this && record.type === type && record.listener === listener) {
            record.removed = true;
          }
        });
      }
      return originalRemoveEventListener.apply(this, arguments);
    };
  }

  function isTargetUrl(url) {
    try {
      const parsed = new URL(url, location.href);
      const target = parseTargetRule(monitorConfig.targetPath || DEFAULT_TARGET_PATH);
      if (!target) return false;
      if (target.mode === 'path') return parsed.pathname === target.pathname;
      if (target.mode === 'host') return parsed.host === target.host && parsed.pathname === target.pathname;
      return parsed.origin === target.origin && parsed.pathname === target.pathname;
    } catch (error) {
      return false;
    }
  }

  function parseTargetRule(value) {
    const target = String(value || DEFAULT_TARGET_PATH).trim() || DEFAULT_TARGET_PATH;
    try {
      if (target.startsWith('//')) {
        const parsed = new URL(`${location.protocol}${target}`);
        return { mode: 'host', host: parsed.host, pathname: parsed.pathname };
      }
      if (/^https?:\/\//i.test(target)) {
        const parsed = new URL(target);
        return { mode: 'origin', origin: parsed.origin, pathname: parsed.pathname };
      }
      const parsed = new URL(target.startsWith('/') ? target : `/${target}`, location.origin);
      return { mode: 'path', pathname: parsed.pathname };
    } catch (error) {
      return null;
    }
  }

  function resolveTargetUrl(value) {
    const target = String(value || DEFAULT_TARGET_PATH).trim() || DEFAULT_TARGET_PATH;
    if (target.startsWith('//')) return new URL(`${location.protocol}${target}`).toString();
    if (/^https?:\/\//i.test(target)) return new URL(target).toString();
    return new URL(target.startsWith('/') ? target : `/${target}`, location.origin).toString();
  }

  function sendPayload(payload) {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'material_list-response',
        payload,
      },
      '*'
    );
  }

  function sendScrollResult(payload) {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-scroll-result',
        payload,
      },
      '*'
    );
  }

  function sendCategorySelectResult(payload) {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-select-category-result',
        payload,
      },
      '*'
    );
  }

  function sendCategoryExpandResult(payload) {
    window.postMessage(
      {
        source: 'buyin-luckybag-monitor',
        type: 'collection-expand-category-result',
        payload,
      },
      '*'
    );
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'buyin-luckybag-monitor') return;
    if (data.type === 'collection-scroll-to-bottom') {
      sendScrollResult(scrollEveryScrollableContainer());
    }
    if (data.type === 'collection-update-config') {
      applyMonitorConfig(data.payload || {});
    }
    if (data.type === 'collection-expand-category-filter') {
      Promise.resolve(ensureCategoryFilterExpanded()).then(sendCategoryExpandResult).catch((error) => {
        sendCategoryExpandResult({
          ok: false,
          reason: error && error.message ? error.message : String(error),
        });
      });
    }
    if (data.type === 'collection-select-category') {
      Promise.resolve(selectLuckybagCategory(data.payload || {}))
        .then(sendCategorySelectResult)
        .catch((error) => {
          sendCategorySelectResult({
            ok: false,
            reason: error && error.message ? error.message : String(error),
          });
        });
    }
  });

  async function readRequestBody(request, init) {
    if (init && typeof init.body !== 'undefined') return parseRequestBody(init.body);
    if (request && typeof request.clone === 'function') {
      try {
        return parseRequestBody(await request.clone().text());
      } catch (error) {
        return null;
      }
    }
    return null;
  }

  function parseRequestBody(body) {
    if (body == null) return null;
    if (typeof body === 'string') return parseBody(body);
    if (body instanceof URLSearchParams) return parseUrlSearchParams(body);
    if (body instanceof FormData) {
      const result = {};
      body.forEach((value, key) => {
        result[key] = value;
      });
      return result;
    }
    return String(body);
  }

  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const request = args[0];
    const init = args[1] || {};
    const url = typeof request === 'string' ? request : request && request.url ? request.url : '';
    const method = (init.method || (request && request.method) || 'GET').toUpperCase();
    const requestPayload = isTargetUrl(url) ? await readRequestBody(request, init) : null;
    if (isTargetUrl(url)) {
      lastMaterialListStartedAt = Date.now();
      rememberMaterialListTemplate(url, method, init, requestPayload);
    }
    const response = await originalFetch.apply(this, args);
    if (isTargetUrl(url)) {
      try {
        const clone = response.clone();
        const text = await clone.text();
        sendPayload({
          url: clone.url || url,
          method,
          status: clone.status,
          type: 'fetch',
          requestPayload,
          body: parseBody(text),
        });
      } catch (error) {
        sendPayload({
          url,
          method,
          status: response.status,
          type: 'fetch',
          requestPayload,
          body: `Failed to read response: ${error && error.message ? error.message : String(error)}`,
        });
      }
    }
    return response;
  };

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this.__buyinMonitorMethod = method;
    this.__buyinMonitorUrl = url;
    return originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const xhr = this;
    const url = xhr.__buyinMonitorUrl;
    const method = String(xhr.__buyinMonitorMethod || 'GET').toUpperCase();
    const requestPayload = isTargetUrl(url) ? parseRequestBody(body) : null;
    if (isTargetUrl(url)) {
      lastMaterialListStartedAt = Date.now();
      rememberMaterialListTemplate(url, method, null, requestPayload);
      xhr.addEventListener('loadend', function () {
        try {
          sendPayload({
            url: xhr.responseURL || url,
            method,
            status: xhr.status,
            type: 'xhr',
            requestPayload,
            body: parseBody(xhr.responseText),
          });
        } catch (error) {
          sendPayload({
            url: xhr.responseURL || url,
            method,
            status: xhr.status,
            type: 'xhr',
            requestPayload,
            body: `Failed to read response: ${error && error.message ? error.message : String(error)}`,
          });
        }
      });
    }
    return originalSend.apply(this, arguments);
  };

  function parseBody(text) {
    if (typeof text !== 'string') return text;
    try {
      return JSON.parse(text);
    } catch (error) {
      const params = new URLSearchParams(text);
      if (Array.from(params.keys()).length > 0) return parseUrlSearchParams(params);
      return text;
    }
  }

  function parseUrlSearchParams(params) {
    const result = {};
    params.forEach((value, key) => {
      result[key] = parseBody(value);
    });
    return result;
  }

  function rememberMaterialListTemplate(url, method, init, requestPayload) {
    lastMaterialListTemplate = {
      url: String(url || location.href),
      method: String(method || 'POST').toUpperCase(),
      credentials: init && init.credentials ? init.credentials : 'include',
      headers: cloneHeaders(init && init.headers),
      requestPayload: cloneJsonLike(requestPayload),
    };
  }

  function applyMonitorConfig(config) {
    if (config.targetPath) monitorConfig.targetPath = String(config.targetPath).trim() || DEFAULT_TARGET_PATH;
    if (config.allRequestTemplate && typeof config.allRequestTemplate === 'object') {
      monitorConfig.allRequestTemplate = cloneJsonLike(config.allRequestTemplate) || monitorConfig.allRequestTemplate;
    }
    if (config.categoryRequestTemplate && typeof config.categoryRequestTemplate === 'object') {
      monitorConfig.categoryRequestTemplate = cloneJsonLike(config.categoryRequestTemplate) || monitorConfig.categoryRequestTemplate;
      monitorConfig.requestTemplate = monitorConfig.categoryRequestTemplate;
    }
    if (config.requestTemplate && typeof config.requestTemplate === 'object') {
      monitorConfig.requestTemplate = cloneJsonLike(config.requestTemplate) || monitorConfig.requestTemplate;
      if (!config.categoryRequestTemplate) monitorConfig.categoryRequestTemplate = monitorConfig.requestTemplate;
    }
  }

  function cloneHeaders(headers) {
    const result = {};
    const blocked = new Set(['content-length', 'cookie', 'host', 'origin', 'referer', 'user-agent']);
    try {
      if (!headers) return result;
      new Headers(headers).forEach((value, key) => {
        if (blocked.has(String(key).toLowerCase())) return;
        result[key] = value;
      });
    } catch (error) {}
    return result;
  }

  function cloneJsonLike(value) {
    if (value == null) return value;
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (error) {
      return value;
    }
  }

  function scrollEveryScrollableContainer() {
    const beforeWindowY = window.scrollY;
    const containers = findScrollableContainers();
    const results = containers.map((el) => scrollElementToBottom(el));
    const maxDocumentHeight = Math.max(
      document.documentElement.scrollHeight,
      document.body ? document.body.scrollHeight : 0
    );

    window.scrollTo(0, maxDocumentHeight);
    document.dispatchEvent(createKeyEvent('keydown'));
    document.dispatchEvent(createKeyEvent('keyup'));
    document.body && document.body.dispatchEvent(createWheelEvent());
    window.dispatchEvent(createWheelEvent());

    const sentinel = findBottomSentinel();
    if (sentinel) sentinel.scrollIntoView({ block: 'end', inline: 'nearest', behavior: 'auto' });

    return {
      beforeWindowY,
      afterWindowY: window.scrollY,
      containerCount: containers.length,
      changedCount: results.filter((item) => item.changed).length,
      maxScrollHeight: Math.max(maxDocumentHeight, ...results.map((item) => item.scrollHeight)),
      containers: results.slice(0, 8),
    };
  }

  async function selectLuckybagCategory(category) {
    const value = normalizeCategoryValue(category.value);
    const name = category.name ? String(category.name) : value == null ? '全部' : '';
    const target = value == null ? findAllCategoryButton() : findBusinessCategoryButton(value, name);
    if (!target) {
      return {
        ok: false,
        value,
        name,
        reason: value == null ? '未找到“全部”类目按钮' : `未找到 business_id_${value} 类目按钮`,
      };
    }

    const beforeSignature = getSelectedCategorySignature();
    const selectStartedAt = Date.now();
    const activation = activateCategoryTarget(target);
    clearEndMarkers();
    const verified = await waitForCategorySelected(value, name);
    if (!verified) {
      const afterSignature = getSelectedCategorySignature();
      return {
        ok: false,
        value,
        name,
        target: describeElement(activation.primary),
        diagnostics: activation.diagnostics,
        reason: `已尝试点击网页类目，但页面未出现对应选中态。命中 ${activation.diagnostics.candidateCount} 个节点，React handler ${activation.diagnostics.reactHandlerCount} 个，页面监听器 ${activation.diagnostics.listenerCount} 个，选中态 ${beforeSignature || '无'} -> ${afterSignature || '无'}`,
      };
    }
    await ensureCategoryFilterExpanded();
    const fallback = await ensureMaterialListRequestedForCategory(value, selectStartedAt);
    return {
      ok: true,
      value,
      name,
      target: describeElement(activation.primary),
      diagnostics: activation.diagnostics,
      fallback,
    };
  }

  function findAllCategoryButton() {
    const containers = Array.from(document.querySelectorAll('.index_module__cateFilterMain___f6e8c'));
    for (const container of containers) {
      const directBoxes = Array.from(container.children).filter((child) => child.matches && child.matches('.index_module__box___fba16'));
      const allButton = directBoxes.find((el) => (el.textContent || '').trim() === '全部');
      if (allButton) return allButton;
    }
    return Array.from(document.querySelectorAll('.index_module__box___fba16')).find((el) => (el.textContent || '').trim() === '全部') || null;
  }

  function findBusinessCategoryButton(value, name) {
    const escaped = typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(String(value)) : String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    const selectors = [
      `.luckybag-filter-cate-cascader-item.business_id_${escaped}`,
      `.luckybag-filter-cate-cascader-item.business_id_${escaped} .index_module__box___fba16`,
      `.business_id_${escaped}`,
      `.business_id_${escaped} .index_module__box___fba16`,
    ];
    for (const selector of selectors) {
      const target = document.querySelector(selector);
      if (target) return target;
    }
    if (!name) return null;
    return Array.from(document.querySelectorAll('.luckybag-filter-cate-cascader-item .index_module__box___fba16')).find(
      (el) => (el.textContent || '').trim() === name
    ) || null;
  }

  function activateCategoryTarget(target) {
    openFilterIfNeeded(target);
    const candidates = getActivationCandidates(target);
    const diagnostics = {
      candidateCount: candidates.length,
      reactHandlerCount: 0,
      listenerCount: 0,
      candidates: candidates.slice(0, 6).map(describeElement),
    };
    candidates.forEach((candidate) => {
      activateElement(candidate);
      diagnostics.reactHandlerCount += invokeReactHandlers(candidate);
      diagnostics.listenerCount += invokeRecordedEventListeners(candidate);
    });
    return { primary: candidates[0] || target, diagnostics };
  }

  function getActivationCandidates(target) {
    const candidates = [];
    const outer = target.closest && target.closest('.luckybag-filter-cate-cascader-item') ? target.closest('.luckybag-filter-cate-cascader-item') : null;
    if (outer) candidates.push(outer);
    candidates.push(target);
    const inner = outer ? outer.querySelector('.index_module__box___fba16') : null;
    if (inner) candidates.push(inner);
    const hit = getElementHitAtCenter(outer || target);
    if (hit) {
      candidates.push(hit);
      const hitOuter = hit.closest && hit.closest('.luckybag-filter-cate-cascader-item') ? hit.closest('.luckybag-filter-cate-cascader-item') : null;
      if (hitOuter) candidates.push(hitOuter);
      if (hit.parentElement && hit.parentElement.matches && hit.parentElement.matches('.luckybag-filter-cate-cascader-item')) {
        candidates.push(hit.parentElement);
      }
    }
    return Array.from(new Set(candidates.filter(Boolean)));
  }

  function openFilterIfNeeded(target) {
    const filter = target.closest && target.closest('[data-react-components*="cate-filter"]');
    if (!filter || isCategoryFilterExpanded(filter)) return;
    const button = getExpandButton(filter);
    if (button) activateElement(button);
  }

  function ensureCategoryFilterExpanded() {
    const filter = document.querySelector('[data-react-components*="cate-filter"]');
    if (!filter) return { ok: false, reason: '未找到奖品类目筛选栏' };
    if (isCategoryFilterExpanded(filter)) {
      return { ok: true, changed: false, state: describeCategoryFilterState(filter) };
    }
    const button = getExpandButton(filter);
    if (!button) return { ok: false, reason: '未找到展开按钮' };
    const before = describeCategoryFilterState(filter);
    activateExpandButton(button);
    return waitForCategoryFilterExpanded(filter, 1000).then((expanded) => {
      if (!expanded) {
        const retryButton = getExpandButton(filter);
        if (retryButton) activateExpandButton(retryButton);
      }
      return waitForCategoryFilterExpanded(filter, 1000).then((finalExpanded) => {
        const forced = finalExpanded ? false : forceCategoryFilterExpanded(filter);
        return {
          ok: finalExpanded || forced,
          changed: true,
          before,
          after: describeCategoryFilterState(filter),
          forced,
          reason: finalExpanded ? '' : '点击展开后未进入展开状态，已启用视觉展开兜底',
        };
      });
    });
  }

  function isCategoryFilterExpanded(filter) {
    if (filter && filter.getAttribute('data-buyin-force-expanded') === 'true') return true;
    const className = String(filter && filter.className ? filter.className : '');
    const buttonText = (getExpandButton(filter)?.textContent || '').trim();
    if (buttonText.includes('展开')) return false;
    if (buttonText.includes('收起')) return true;
    return className.includes('expand') && !className.includes('notExpand');
  }

  function describeCategoryFilterState(filter) {
    const className = String(filter && filter.className ? filter.className : '');
    const buttonText = (getExpandButton(filter)?.textContent || '').trim();
    return `${className} | ${buttonText}`;
  }

  function waitForCategoryFilterExpanded(filter, timeout = 2000) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const check = () => {
        if (isCategoryFilterExpanded(filter)) {
          resolve(true);
          return;
        }
        if (Date.now() - startedAt >= timeout) {
          resolve(false);
          return;
        }
        window.setTimeout(check, 80);
      };
      check();
    });
  }

  function forceCategoryFilterExpanded(filter) {
    try {
      applyCategoryFilterExpandedStyle(filter);
      return true;
    } catch (error) {
      return false;
    }
  }

  function applyCategoryFilterExpandedStyle(filter) {
    if (!filter) return;
    const wrapper = filter.closest('.table-cell.body') || filter.parentElement || filter;
    if (filter.classList.contains('index_module__notExpand___f6e8c')) {
      filter.classList.remove('index_module__notExpand___f6e8c');
    }
    if (!filter.classList.contains('index_module__expand___f6e8c')) {
      filter.classList.add('index_module__expand___f6e8c');
    }
    const button = getExpandButton(filter);
    if (button) {
      const buttonText = button.querySelector('span');
      if (buttonText) buttonText.textContent = '收起';
    }
    ensureForceCategoryExpandStyle();
    filter.setAttribute('data-buyin-force-expanded', 'true');
    wrapper.setAttribute('data-buyin-force-expanded-wrapper', 'true');
  }

  function ensureForceCategoryExpandStyle() {
    if (document.getElementById(FORCE_CATEGORY_EXPAND_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = FORCE_CATEGORY_EXPAND_STYLE_ID;
    style.textContent = `
      [data-buyin-force-expanded="true"] {
        max-height: none !important;
        height: auto !important;
        overflow: visible !important;
      }
      [data-buyin-force-expanded-wrapper="true"] {
        overflow: visible !important;
      }
      [data-buyin-force-expanded="true"] .index_module__cateFilterMain___f6e8c {
        max-height: none !important;
        height: auto !important;
        overflow: visible !important;
      }
      [data-buyin-force-expanded="true"] .index_module__CascaderSelector___f6e8c {
        display: inline-flex !important;
        visibility: visible !important;
      }
      [data-buyin-force-expanded="true"] .index_module__expandButton___f6e8c button span:first-child {
        content: '收起';
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function getExpandButton(filter) {
    return filter && filter.querySelector('.index_module__expandButton___f6e8c button, .index_module__expandButton___f6e8c');
  }

  function activateExpandButton(button) {
    const wrapper = button.closest && button.closest('.index_module__expandButton___f6e8c');
    const hit = getElementHitAtCenter(button);
    const candidates = Array.from(new Set([button, wrapper, hit, hit && hit.parentElement].filter(Boolean)));
    candidates.forEach((candidate) => {
      activateElement(candidate);
      invokeReactHandlers(candidate);
      invokeRecordedEventListeners(candidate);
    });
  }

  function getElementHitAtCenter(element) {
    if (!element || typeof document.elementFromPoint !== 'function') return null;
    element.scrollIntoView({ block: 'center', inline: 'center', behavior: 'auto' });
    const rect = element.getBoundingClientRect();
    const clientX = Math.round(rect.left + rect.width / 2);
    const clientY = Math.round(rect.top + rect.height / 2);
    return document.elementFromPoint(clientX, clientY);
  }

  function activateElement(element) {
    element.scrollIntoView({ block: 'center', inline: 'center', behavior: 'auto' });
    const rect = element.getBoundingClientRect();
    const clientX = Math.round(rect.left + rect.width / 2);
    const clientY = Math.round(rect.top + rect.height / 2);
    element.focus && element.focus({ preventScroll: true });
    element.dispatchEvent(createPointerEvent('pointerover', clientX, clientY));
    element.dispatchEvent(createPointerEvent('pointerenter', clientX, clientY));
    element.dispatchEvent(createMouseEvent('mouseover', clientX, clientY));
    element.dispatchEvent(createMouseEvent('mouseenter', clientX, clientY));
    element.dispatchEvent(createPointerEvent('pointerdown', clientX, clientY));
    element.dispatchEvent(createMouseEvent('mousedown', clientX, clientY));
    element.dispatchEvent(createPointerEvent('pointerup', clientX, clientY));
    element.dispatchEvent(createMouseEvent('mouseup', clientX, clientY));
    element.dispatchEvent(createMouseEvent('click', clientX, clientY));
    element.click && element.click();
  }

  function invokeReactHandlers(element) {
    let invoked = 0;
    getReactProps(element).forEach((props) => {
      ['onPointerDown', 'onMouseDown', 'onMouseUp', 'onClick'].forEach((name) => {
        if (typeof props[name] === 'function') {
          try {
            props[name](createSyntheticEvent(element, name));
            invoked += 1;
          } catch (error) {}
        }
      });
    });
    return invoked;
  }

  function invokeRecordedEventListeners(element) {
    let invoked = 0;
    recordedEventListeners.forEach((record) => {
      if (record.removed || !record.target || !record.listener) return;
      if (!isListenerRelevant(record.target, element)) return;
      try {
        const event = createRecordedEvent(record.type, element, record.target);
        if (typeof record.listener === 'function') {
          record.listener.call(record.target, event);
        } else if (record.listener && typeof record.listener.handleEvent === 'function') {
          record.listener.handleEvent(event);
        }
        invoked += 1;
      } catch (error) {}
    });
    return invoked;
  }

  function isListenerRelevant(listenerTarget, element) {
    if (listenerTarget === window || listenerTarget === document || listenerTarget === document.body || listenerTarget === document.documentElement) return true;
    if (!listenerTarget || typeof listenerTarget.contains !== 'function') return false;
    return listenerTarget === element || listenerTarget.contains(element) || (element.contains && element.contains(listenerTarget));
  }

  function getReactProps(element) {
    const props = [];
    let current = element;
    while (current && current !== document.documentElement) {
      Object.keys(current).forEach((key) => {
        if (key.startsWith('__reactProps$') || key.startsWith('__reactEventHandlers$')) {
          props.push(current[key]);
        }
        if (key.startsWith('__reactFiber$') || key.startsWith('__reactInternalInstance$')) {
          collectFiberProps(current[key], props);
        }
      });
      current = current.parentElement;
    }
    return props.filter(Boolean);
  }

  function collectFiberProps(fiber, props) {
    const seen = new Set();
    let current = fiber;
    while (current && !seen.has(current)) {
      seen.add(current);
      if (current.memoizedProps) props.push(current.memoizedProps);
      if (current.pendingProps && current.pendingProps !== current.memoizedProps) props.push(current.pendingProps);
      current = current.return;
    }
  }

  function createSyntheticEvent(target, handlerName = 'onClick') {
    return {
      target,
      currentTarget: target,
      nativeEvent: createMouseEvent(handlerName.toLowerCase().replace(/^on/, '') || 'click'),
      type: handlerName.toLowerCase().replace(/^on/, '') || 'click',
      button: 0,
      buttons: 0,
      bubbles: true,
      cancelable: true,
      defaultPrevented: false,
      isTrusted: true,
      preventDefault() {
        this.defaultPrevented = true;
      },
      stopPropagation() {},
      stopImmediatePropagation() {},
      persist() {},
      isDefaultPrevented() {
        return this.defaultPrevented;
      },
      isPropagationStopped() {
        return false;
      },
    };
  }

  function createRecordedEvent(type, target, currentTarget) {
    return {
      type,
      target,
      srcElement: target,
      currentTarget,
      delegateTarget: currentTarget,
      view: window,
      bubbles: true,
      cancelable: true,
      isTrusted: true,
      button: 0,
      buttons: type === 'mousedown' || type === 'pointerdown' ? 1 : 0,
      clientX: getElementCenter(target).clientX,
      clientY: getElementCenter(target).clientY,
      pageX: getElementCenter(target).clientX + window.scrollX,
      pageY: getElementCenter(target).clientY + window.scrollY,
      pointerId: 1,
      pointerType: 'mouse',
      isPrimary: true,
      timeStamp: Date.now(),
      defaultPrevented: false,
      composedPath: () => getEventPath(target),
      preventDefault() {
        this.defaultPrevented = true;
      },
      stopPropagation() {},
      stopImmediatePropagation() {},
    };
  }

  function getElementCenter(element) {
    if (!element || typeof element.getBoundingClientRect !== 'function') return { clientX: 0, clientY: 0 };
    const rect = element.getBoundingClientRect();
    return {
      clientX: Math.round(rect.left + rect.width / 2),
      clientY: Math.round(rect.top + rect.height / 2),
    };
  }

  function getEventPath(target) {
    const path = [];
    let current = target;
    while (current) {
      path.push(current);
      current = current.parentNode || current.host;
    }
    path.push(window);
    return path;
  }

  function waitForCategorySelected(value, name) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const check = () => {
        if (isCategorySelected(value, name)) {
          resolve(true);
          return;
        }
        if (Date.now() - startedAt >= 1800) {
          resolve(false);
          return;
        }
        window.setTimeout(check, 120);
      };
      check();
    });
  }

  function isCategorySelected(value, name) {
    if (value == null) {
      const allButton = findAllCategoryButton();
      return Boolean(allButton && allButton.className && String(allButton.className).includes('active'));
    }
    const target = findBusinessCategoryButton(value, name);
    const outer = target && target.closest ? target.closest('.luckybag-filter-cate-cascader-item') : null;
    if (outer && outer.querySelector('.index_module__active___fba16')) return true;
    return Array.from(document.querySelectorAll('.table-cell.body.selected, [data-react-components*="selected-line"]')).some((node) => {
      const text = node.textContent || '';
      return text.includes(name) || text.includes(`商品类目: ${name}`);
    });
  }

  function getSelectedCategorySignature() {
    const selected = Array.from(document.querySelectorAll('.table-cell.body.selected, [data-react-components*="selected-line"]'))
      .map((node) => (node.textContent || '').trim())
      .filter(Boolean)
      .join('|');
    const active = Array.from(document.querySelectorAll('.index_module__cateFilterMain___f6e8c .index_module__active___fba16'))
      .map((node) => (node.textContent || '').trim())
      .filter(Boolean)
      .join('|');
    return selected || active;
  }

  async function ensureMaterialListRequestedForCategory(value, selectStartedAt) {
    await wait(900);
    if (lastMaterialListStartedAt >= selectStartedAt) {
      return { mode: 'page-requested' };
    }
    const template = lastMaterialListTemplate || createDefaultMaterialListTemplate();
    const baseTemplate = value == null ? getRequestTemplateForCategory(value) : template.requestPayload || getRequestTemplateForCategory(value);
    const requestPayload = buildCategoryRequestPayload(baseTemplate, value);
    const body = JSON.stringify(requestPayload);
    const headers = Object.assign({}, template.headers || {});
    headers['content-type'] = headers['content-type'] || headers['Content-Type'] || 'application/json';
    try {
      const response = await originalFetch.call(window, template.url, {
        method: template.method || 'POST',
        credentials: template.credentials || 'include',
        headers,
        body,
      });
      lastMaterialListStartedAt = Date.now();
      rememberMaterialListTemplate(template.url, template.method || 'POST', { headers, credentials: template.credentials }, requestPayload);
      const text = await response.clone().text();
      sendPayload({
        url: response.url || template.url,
        method: template.method || 'POST',
        status: response.status,
        type: 'fetch-fallback',
        requestPayload,
        body: parseBody(text),
      });
      return { mode: 'fallback-fetch', status: response.status };
    } catch (error) {
      return { mode: 'failed', reason: error && error.message ? error.message : String(error) };
    }
  }

  function buildCategoryRequestPayload(source, value) {
    const payload = cloneJsonLike(source) || cloneJsonLike(getRequestTemplateForCategory(value)) || {};
    const replaced = value == null ? false : replaceCategoryPlaceholder(payload, String(value));
    if (value == null) {
      if (payload.filters && typeof payload.filters === 'object' && !Array.isArray(payload.filters)) delete payload.filters.BusinessCid;
    } else if (!replaced) {
      if (!payload.filters || typeof payload.filters !== 'object' || Array.isArray(payload.filters)) payload.filters = {};
      payload.filters.BusinessCid = { value: [String(value)] };
    }
    if ('page' in payload) payload.page = 1;
    if ('page_num' in payload) payload.page_num = 1;
    if ('pageNum' in payload) payload.pageNum = 1;
    if ('offset' in payload) payload.offset = 0;
    if ('cursor' in payload) delete payload.cursor;
    if ('search_after' in payload) delete payload.search_after;
    return payload;
  }

  function replaceCategoryPlaceholder(target, value) {
    let replaced = false;
    const walk = (node) => {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) {
        node.forEach((item, index) => {
          if (item === '__CATEGORY_ID__') {
            node[index] = value;
            replaced = true;
          } else {
            walk(item);
          }
        });
        return;
      }
      Object.keys(node).forEach((key) => {
        if (node[key] === '__CATEGORY_ID__') {
          node[key] = value;
          replaced = true;
          return;
        }
        walk(node[key]);
      });
    };
    walk(target);
    return replaced;
  }

  function getRequestTemplateForCategory(value) {
    return value == null
      ? monitorConfig.allRequestTemplate || { filters: {} }
      : monitorConfig.categoryRequestTemplate || monitorConfig.requestTemplate || { filters: { BusinessCid: { value: ['__CATEGORY_ID__'] } } };
  }

  function createDefaultMaterialListTemplate() {
    return {
      url: resolveTargetUrl(monitorConfig.targetPath || DEFAULT_TARGET_PATH),
      method: 'POST',
      credentials: 'include',
      headers: {},
      requestPayload: cloneJsonLike(monitorConfig.categoryRequestTemplate || monitorConfig.requestTemplate),
    };
  }

  function wait(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function clearEndMarkers() {
    Array.from(document.querySelectorAll('.sp-infinit-end')).forEach((node) => {
      if (node && node.parentNode) node.parentNode.removeChild(node);
    });
  }

  function normalizeCategoryValue(value) {
    const text = value == null ? '' : String(value).trim();
    return text ? text : null;
  }

  function findScrollableContainers() {
    const all = [document.scrollingElement, document.documentElement, document.body]
      .concat(Array.from(document.querySelectorAll('body *')))
      .filter(Boolean);
    const unique = Array.from(new Set(all));

    return unique
      .filter((el) => {
        if (!el || typeof el.scrollHeight !== 'number') return false;
        if (el.scrollHeight - el.clientHeight <= 40) return false;
        if (el.closest && el.closest('#buyin-luckybag-monitor-root')) return false;
        if (el === document.documentElement || el === document.body || el === document.scrollingElement) return true;
        const style = window.getComputedStyle(el);
        const overflowY = style.overflowY;
        return overflowY === 'auto' || overflowY === 'scroll' || overflowY === 'overlay' || style.position === 'fixed';
      })
      .sort((a, b) => b.scrollHeight - a.scrollHeight);
  }

  function scrollElementToBottom(el) {
    const before = el.scrollTop || 0;
    const maxTop = Math.max(0, el.scrollHeight - el.clientHeight);
    el.scrollTop = maxTop;
    el.dispatchEvent(createScrollEvent());
    el.dispatchEvent(createWheelEvent());

    return {
      name: describeElement(el),
      before,
      after: el.scrollTop || 0,
      scrollHeight: el.scrollHeight,
      clientHeight: el.clientHeight,
      changed: before !== (el.scrollTop || 0),
    };
  }

  function findBottomSentinel() {
    const selectors = [
      '.sp-infinit-end',
      '[elementtiming="element-timing"]',
      '[class*="infinite"]',
      '[class*="list"] > *:last-child',
      '[class*="card"]:last-child',
      '[class*="item"]:last-child',
    ];
    for (const selector of selectors) {
      const nodes = Array.from(document.querySelectorAll(selector));
      if (nodes.length > 0) return nodes[nodes.length - 1];
    }
    return document.body;
  }

  function describeElement(el) {
    if (el === document.scrollingElement || el === document.documentElement || el === document.body) return '页面主滚动条';
    const id = el.id ? `#${el.id}` : '';
    const className = typeof el.className === 'string' && el.className.trim() ? `.${el.className.trim().split(/\s+/).slice(0, 2).join('.')}` : '';
    return `${el.tagName.toLowerCase()}${id}${className}`;
  }

  function createWheelEvent() {
    return new WheelEvent('wheel', {
      bubbles: true,
      cancelable: true,
      deltaY: 2400,
      deltaMode: 0,
    });
  }

  function createScrollEvent() {
    return new Event('scroll', {
      bubbles: true,
      cancelable: false,
    });
  }

  function createMouseEvent(type, clientX = 0, clientY = 0) {
    return new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window,
      button: 0,
      buttons: type === 'mousedown' ? 1 : 0,
      clientX,
      clientY,
    });
  }

  function createPointerEvent(type, clientX = 0, clientY = 0) {
    if (typeof PointerEvent === 'function') {
      return new PointerEvent(type, {
        bubbles: true,
        cancelable: true,
        view: window,
        pointerId: 1,
        pointerType: 'mouse',
        isPrimary: true,
        button: 0,
        buttons: type === 'pointerdown' ? 1 : 0,
        clientX,
        clientY,
      });
    }
    return createMouseEvent(type.replace('pointer', 'mouse'), clientX, clientY);
  }

  function createKeyEvent(type) {
    return new KeyboardEvent(type, {
      key: 'End',
      code: 'End',
      keyCode: 35,
      which: 35,
      bubbles: true,
      cancelable: true,
    });
  }
})();
