﻿(function () {
  "use strict";

  const runtime = typeof browser !== "undefined" && browser.runtime ? browser.runtime : typeof chrome !== "undefined" && chrome.runtime ? chrome.runtime : null;
  const manifest = runtime && runtime.getManifest ? runtime.getManifest() : { name: "巨量百应超级福袋采集助手", version: "1.8.6" };
  const root = document.documentElement;
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)");
  const storage = window.localStorage;
  const RELEASE_REPO = "52xd/buyin-luckybag-monitor-release";
  const RELEASE_API_BASE = `https://api.github.com/repos/${RELEASE_REPO}`;
  const RELEASE_PAGE_URL = `https://github.com/${RELEASE_REPO}/tags`;
  const RELEASE_ARCHIVE_BASE = `https://github.com/${RELEASE_REPO}/archive/refs/tags`;
  const RELEASE_CHANGELOG_URL = `https://raw.githubusercontent.com/${RELEASE_REPO}/main/Update.json`;
  const PRIZE_ID_ICON_SRC = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iIzU2NTk2MCIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMi41IDJoMi42NjdsLTIgMTFILjV6bTQuNjY2IDBoLS4zMzNsLjIxNi42NDgtMS43NTcgOS42NjQtLjQ2LjY4OUg5LjVjMi42NjcgMCA0Ljc1LTEuMDE3IDUuNjY3LTQgMS4zMzQtNC4zMzQtLjMzMy03LTMuMzMzLTd6TTkuNSA0LjMzM2wtMS4zMzQgNi4zMzNoMmMuNjY3IDAgMi0uMzM0IDIuNjY3LTIuMzMzcy4zMzMtNC0xLjY2Ny00eiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0ibTUuMTY3IDIgLjI0Ni4wNDUuMDUzLS4yOTVoLS4zek0yLjUgMnYtLjI1aC0uMjA5bC0uMDM3LjIwNnptLjY2NyAxMXYuMjVoLjIwOGwuMDM4LS4yMDV6TS41IDEzbC0uMjQ2LS4wNDQtLjA1NC4yOTVoLjN6TTYuODMzIDJ2LS4yNWgtLjM0N2wuMTEuMzN6bS4zMzMgMGguMjV2LS4yNWgtLjI1em0tLjExNy42NDguMjQ2LjA0NS4wMTEtLjA2My0uMDItLjA2MXptLTEuNzU3IDkuNjY0LjIwOC4xNC4wMjgtLjA0NC4wMS0uMDV6bS0uNDYuNjg5LS4yMDctLjE0LS4yNi4zOWguNDY4em0xMC4zMzQtNC0uMjM5LS4wNzR6bS04LTd2LS4yNWgtLjIwOGwtLjAzOC4yMDV6bTAgMGgtLjI1bC40OTYuMDQ1em0xIDguNjY1LS4yNDQtLjA1Mi0uMDY0LjMwMmguMzA4ek05LjUgNC4zMzN2LS4yNWgtLjIwM2wtLjA0Mi4xOTh6bTMuMzMzIDQtLjIzNy0uMDh6TTUuMTY3IDEuNzVIMi41di41aDIuNjY3ek0zLjQxMyAxMy4wNDVsMi0xMS0uNDkyLS4wOS0yIDExek0uNSAxMy4yNTFoMi42Njd2LS41SC41ek0yLjI1NCAxLjk1NmwtMiAxMSAuNDkyLjA5IDItMTF6bTQuNTc5LjI5NGguMzMzdi0uNWgtLjMzM3ptLjQ1My4zMTlMNy4wNyAxLjkybC0uNDc0LjE1OS4yMTYuNjQ3em0tMS43NDkgOS43ODggMS43NTgtOS42NjQtLjQ5Mi0uMDktMS43NTcgOS42NjV6bS0uNDk2Ljc4Mi40NTktLjY4OC0uNDE2LS4yNzctLjQ2LjY4OHptLjEyNS0uMzg4aC0uMzMzdi41aC4zMzN6bS4zMzMgMGgtLjMzM3YuNUg1LjV6bTQgMGgtNHYuNWg0em01LjQyOS0zLjgyNGMtLjQ0NSAxLjQ0Ni0xLjE2NCAyLjM5My0yLjA3NSAyLjk4Mi0uOTE1LjU5My0yLjA1Ljg0MS0zLjM1My44NDF2LjVjMS4zNjMgMCAyLjYwMi0uMjYgMy42MjUtLjkyIDEuMDI2LS42NjUgMS44MDctMS43MTkgMi4yOC0zLjI1NnpNMTEuODMzIDIuMjVjMS40MTggMCAyLjQ5My42MjUgMy4wNyAxLjc0LjU4NCAxLjEzLjY4IDIuODA2LjAyNCA0LjkzN2wuNDc4LjE0N2MuNjc4LTIuMjAzLjYwOC00LjAyNi0uMDU4LTUuMzEzLS42NzMtMS4zMDEtMS45MzItMi4wMS0zLjUxNC0yLjAxem0tNC42NjcgMGg0LjY2N3YtLjVINy4xNjZ6bS4yNDYtLjIwNC0uNDkyLS4wOXpNNi45MTYgMnYuMDAxaC41em0xLjQ5NSA4LjcxNyAxLjMzMy02LjMzMy0uNDg5LS4xMDMtMS4zMzMgNi4zMzN6bTEuNzU1LS4zMDFoLTJ2LjVoMnptMi40My0yLjE2M2MtLjMxOC45NTQtLjc4NyAxLjQ5LTEuMjM1IDEuNzg4LS40NTEuMzAxLS45LjM3NS0xLjE5NS4zNzV2LjVjLjM3MyAwIC45MjQtLjA5MyAxLjQ3Mi0uNDU5LjU1Mi0uMzY4IDEuMDg0LTEgMS40MzItMi4wNDV6bS0xLjQzLTMuNjdjLjQ1OCAwIC44LjExMyAxLjA1Mi4yOTYuMjUyLjE4Mi40MzMuNDQ4LjU0NS43ODMuMjI2LjY3OC4xNTcgMS42MTgtLjE2NyAyLjU5MWwuNDc0LjE1OWMuMzQzLTEuMDI3LjQ0LTIuMDg3LjE2Ny0yLjkwOS0uMTM5LS40MTUtLjM3NC0uNzc0LS43MjYtMS4wMy0uMzUyLS4yNTQtLjgwMi0uMzktMS4zNDUtLjM5em0tMS42NjYgMGgxLjY2NnYtLjVIOS41eiIvPjwvc3ZnPg==";
  const PRIZE_DIVIDER_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAB50lEQVR4AeyW21XCQBCGk9CAJaANGLk8mw5MCUoByqEBoAGFBkQ7QBsQn7mFCqADLYBD/HZJVthcDyA+aM78u9mZf/bPbjYDlnHk6/cEba5yudzLATfcFLguyMypVqt2mKNWaJpmHed1DjzAEWbSNEFmju/7t/CkKUE5oiG4oHuKgYdPt5PAIWKRnGCugLLuIoKsdDAej290kPyyTom2IqbzGdfwv+vsiKBOOPT4X/DQO2rEbaldKpVaOjhMl0nqIqbzGTctyzrXc2IFmaCpg0QHCPsUjQZH54sxHPXBcy9NCfI0fTweR3mRBiZ6hicMmt/lJjWH+BziK700Jch30wcXk8nkNA2j0agjM2ngdbJyiJ8BsRgyjNh3KAM/1agVUoRdXvQ8DXCmxEXNDZ/HxPdWqVTuQ8dGHxtTgqvVyuX9FNPAZDbxO3ppiImD5PCO6vzYFKUzaJJiSjDgiU4cgjaTbIHAAOxtsYIchpYOHiBSiHdRjxPcZZ7cOX9X0GSPdODa3+K21OFIP+qg9F3tL2d8Vxq+Lz+YUHxPkT9GnFJZiOk/Ap6xXC43C/nmfWJMrbBQKHQR7WWBlTZCwdlsNoXfBg3P87YEk2JKcDgcehTmWg5sFQD4LaAKevgwoscfiSlBQTgGvgAAAP//ywJbnQAAAAZJREFUAwAc4ZRIaae/YgAAAABJRU5ErkJggg==";

  const STORAGE_KEYS = {
    auth: "buyinAuthState",
    users: "buyinUsers",
    userSettings: "buyinUserSettings",
    categories: "buyinCategories",
    monitorConfig: "buyinMonitorConfig",
    prizeLibrary: "buyinPrizeLibrary"
  };

  const DEFAULT_CATEGORIES = [
    { name: "全部", value: null },
    { name: "美妆", value: "9" },
    { name: "智能家居", value: "7" },
    { name: "3C数码家电", value: "14" },
    { name: "个护家清", value: "5" },
    { name: "珠宝文玩", value: "20" },
    { name: "服饰内衣", value: "4" },
    { name: "食品饮料", value: "13" },
    { name: "母婴宠物", value: "10" },
    { name: "运动户外", value: "18" },
    { name: "玩具乐器", value: "2" },
    { name: "酒类", value: "23" },
    { name: "钟表配饰", value: "19" },
    { name: "礼品文创", value: "6" },
    { name: "鲜花园艺", value: "11" },
    { name: "图书教育", value: "15" },
    { name: "鞋靴箱包", value: "16" },
    { name: "滋补保健", value: "24" },
    { name: "虚拟充值", value: "17" },
    { name: "生鲜", value: "8" }
  ];

  const DEFAULT_MONITOR_CONFIG = {
    targetPath: "/pc/selection/common/material_list",
    allRequestTemplate: { filters: {} },
    categoryRequestTemplate: { filters: { BusinessCid: { value: ["__CATEGORY_ID__"] } } },
    requestTemplate: { filters: { BusinessCid: { value: ["__CATEGORY_ID__"] } } }
  };

  const metrics = {
    accountTotal: 0,
    newUsers: 0,
    prizeTotal: 0,
    newPrizes: 0,
    shopTotal: 0,
    newShops: 0
  };

  const dictionaries = {
    "zh-CN": {
      appName: "巨量百应超级福袋采集助手",
      versionLabel: "版本",
      searchPlaceholder: "搜索设置、页面或功能",
      tabOverview: "首页总览",
      tabPrizes: "奖品总库",
      tabShops: "奖品店铺",
      tabRanking: "奖品排行榜",
      tabSettings: "设置",
      tabAbout: "关于",
      overviewEyebrow: "数据概览",
      overviewTitle: "首页总览",
      accountTotal: "账户总数量",
      newUsers: "新增用户",
      prizeTotal: "奖品总数量",
      newPrizes: "新增奖品",
      shopTotal: "店铺总数量",
      newShops: "新增店铺",
      extensionVersion: "扩展版本",
      checkUpdate: "立即更新",
      updateIdle: "尚未检查更新",
      updateLatest: "当前已是最新版本",
      unitCount: "个",
      noResults: "未找到设置",
      jump: "跳转",
      addedNone: "暂无新增",
      addedSome: "今日新增"
    },
    "zh-TW": {
      appName: "巨量百應超級福袋採集助手",
      versionLabel: "版本",
      searchPlaceholder: "搜尋設定、頁面或功能",
      tabOverview: "首頁總覽",
      tabPrizes: "獎品總庫",
      tabShops: "獎品店鋪",
      tabRanking: "獎品排行榜",
      tabSettings: "設定",
      tabAbout: "關於",
      overviewEyebrow: "資料概覽",
      overviewTitle: "首頁總覽",
      accountTotal: "帳戶總數量",
      newUsers: "新增使用者",
      prizeTotal: "獎品總數量",
      newPrizes: "新增獎品",
      shopTotal: "店鋪總數量",
      newShops: "新增店鋪",
      extensionVersion: "擴充版本",
      checkUpdate: "立即更新",
      updateIdle: "尚未檢查更新",
      updateLatest: "目前已是最新版本",
      unitCount: "個",
      noResults: "未找到設定",
      jump: "前往",
      addedNone: "暫無新增",
      addedSome: "今日新增"
    },
    en: {
      appName: "Buyin Lucky Bag Collection Assistant",
      versionLabel: "Version",
      searchPlaceholder: "Search settings, pages, or features",
      tabOverview: "Overview",
      tabPrizes: "Prize Library",
      tabShops: "Prize Shops",
      tabRanking: "Prize Ranking",
      tabSettings: "Settings",
      tabAbout: "About",
      overviewEyebrow: "Dashboard",
      overviewTitle: "Overview",
      accountTotal: "Total Accounts",
      newUsers: "New Users",
      prizeTotal: "Total Prizes",
      newPrizes: "New Prizes",
      shopTotal: "Total Shops",
      newShops: "New Shops",
      extensionVersion: "Extension Version",
      checkUpdate: "Update Now",
      updateIdle: "Not checked yet",
      updateLatest: "You are on the latest version",
      unitCount: "",
      noResults: "No settings found",
      jump: "Open",
      addedNone: "No new items",
      addedSome: "New today"
    }
  };

  let activeLanguage = storage.getItem("buyinOptionsLanguage") || "zh-CN";
  let activeTheme = storage.getItem("buyinOptionsTheme") || "system";
  let authState = { mode: "guest", username: "" };
  let users = {};
  let categories = normalizeCategoryList(DEFAULT_CATEGORIES);
  let monitorConfig = normalizeMonitorConfig(DEFAULT_MONITOR_CONFIG);
  let draggedIndex = null;
  let toastRoot = null;
  let prizeLibrary = {};
  let prizeLibraryVisibleCount = 20;
  let prizeLibraryObserver = null;
  let updateActionState = "ready";

  function t(key) {
    return (dictionaries[activeLanguage] && dictionaries[activeLanguage][key]) || dictionaries["zh-CN"][key] || key;
  }

  function applyTheme() {
    const resolved = activeTheme === "system" ? (prefersDark.matches ? "dark" : "light") : activeTheme;
    root.dataset.theme = resolved;
    document.querySelectorAll("[data-theme-choice]").forEach((button) => {
      button.classList.toggle("active", button.dataset.themeChoice === activeTheme);
    });
  }

  function applyLanguage() {
    document.documentElement.lang = activeLanguage;
    document.querySelectorAll("[data-i18n]").forEach((node) => {
      node.textContent = t(node.dataset.i18n);
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((node) => {
      node.setAttribute("placeholder", t(node.dataset.i18nPlaceholder));
    });
    const languageSelect = document.getElementById("languageSelect");
    if (languageSelect) languageSelect.value = activeLanguage;
    renderMetrics();
  }

  function setActiveTab(tabName, shouldScroll) {
    document.querySelectorAll(".tab").forEach((tab) => {
      tab.classList.toggle("active", tab.dataset.tab === tabName);
    });
    document.querySelectorAll(".panel").forEach((panel) => {
      panel.classList.toggle("active", panel.dataset.panel === tabName);
    });
    const panel = document.querySelector(`.panel[data-panel="${tabName}"]`);
    if (panel && shouldScroll) {
      panel.scrollIntoView({ behavior: "smooth", block: "start" });
      panel.classList.add("highlight-target");
      window.setTimeout(() => panel.classList.remove("highlight-target"), 1200);
    }
  }

  function renderMetrics() {
    Object.entries(metrics).forEach(([key, value]) => {
      document.querySelectorAll(`[data-stat="${key}"]`).forEach((node) => {
        node.textContent = String(value);
      });
      const delta = document.querySelector(`[data-delta="${key}"]`);
      if (delta) {
        delta.classList.toggle("positive", value > 0);
        delta.classList.toggle("neutral", value <= 0);
        const label = delta.querySelector("span");
        if (label) {
          const baseKey = key === "newUsers" ? "newUsers" : key === "newPrizes" ? "newPrizes" : "newShops";
          label.textContent = value > 0 ? `${t("addedSome")} ${t(baseKey)}` : `${t(baseKey)} - ${t("addedNone")}`;
        }
      }
    });
  }

  function getSearchItems() {
    return Array.from(document.querySelectorAll(".panel, .settings-card, .stat-card")).map((node) => {
      const panel = node.classList.contains("panel") ? node : node.closest(".panel");
      const tabName = panel ? panel.dataset.panel : "overview";
      const tab = document.querySelector(`.tab[data-tab="${tabName}"] span`);
      const heading = node.querySelector("h1, h2") || tab;
      return {
        tabName,
        title: heading ? heading.textContent.trim() : tabName,
        keywords: `${node.dataset.searchKeywords || ""} ${tab ? tab.textContent : ""} ${heading ? heading.textContent : ""}`.toLowerCase()
      };
    });
  }

  function renderSearchResults(query) {
    const resultsBox = document.getElementById("searchResults");
    const normalized = query.trim().toLowerCase();
    if (!resultsBox || !normalized) {
      if (resultsBox) resultsBox.hidden = true;
      return;
    }
    const matches = getSearchItems().filter((item) => item.keywords.includes(normalized) || item.title.toLowerCase().includes(normalized));
    resultsBox.innerHTML = "";
    if (!matches.length) {
      const empty = document.createElement("div");
      empty.className = "search-result";
      empty.textContent = t("noResults");
      resultsBox.append(empty);
      resultsBox.hidden = false;
      return;
    }
    matches.slice(0, 8).forEach((item) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "search-result";
      const title = document.createElement("span");
      title.textContent = item.title;
      const small = document.createElement("small");
      small.textContent = t("jump");
      button.append(title, small);
      button.addEventListener("click", () => {
        setActiveTab(item.tabName, true);
        resultsBox.hidden = true;
        document.getElementById("settingSearch").value = "";
      });
      resultsBox.append(button);
    });
    resultsBox.hidden = false;
  }

  async function loadSharedState() {
    authState = await storageGet(STORAGE_KEYS.auth, { mode: "guest", username: "" });
    users = await storageGet(STORAGE_KEYS.users, {});
    const settings = await loadCurrentUserSettings();
    categories = settings.categories;
    monitorConfig = settings.monitorConfig;
    prizeLibrary = await storageGet(STORAGE_KEYS.prizeLibrary, {});
    renderUserMetrics();
    renderAccountLock();
    renderCategories();
    renderMonitorConfig();
  }

  function renderAccountLock() {
    root.dataset.optionsLocked = String(!isLoggedIn());
    const accountName = document.querySelector("[data-options-account-name]");
    if (accountName) accountName.textContent = isLoggedIn() ? authState.username : "游客模式";
  }

  function renderCategories() {
    const list = document.querySelector("[data-options-category-list]");
    if (!list) return;
    list.innerHTML = "";
    categories.forEach((item, index) => {
      const row = document.createElement("div");
      row.className = "option-category-item";
      row.dataset.index = String(index);
      if (!isAllCategory(item, index)) row.draggable = true;

      const handle = document.createElement("div");
      handle.className = `drag-handle${isAllCategory(item, index) ? " locked" : ""}`;
      handle.innerHTML = '<svg class="icon"><use href="#icon-grip" /></svg>';

      const fields = document.createElement("div");
      fields.className = "category-card-fields";

      const nameInput = document.createElement("input");
      nameInput.className = "category-name-input";
      nameInput.value = item.name;
      nameInput.maxLength = 24;
      nameInput.setAttribute("aria-label", "类目名称");
      nameInput.addEventListener("change", () => updateCategory(index, { name: nameInput.value.trim() || "新类目" }));

      const valueWrap = document.createElement("label");
      valueWrap.className = "category-id-field";
      const valueLabel = document.createElement("span");
      valueLabel.textContent = "ID";
      const valueInput = document.createElement("input");
      valueInput.value = item.value == null ? "" : item.value;
      valueInput.placeholder = "类目ID";
      valueInput.disabled = isAllCategory(item, index);
      valueInput.setAttribute("aria-label", "类目ID");
      valueInput.addEventListener("change", () => updateCategory(index, { value: normalizeCategoryValue(valueInput.value) }));
      valueWrap.append(valueLabel, valueInput);
      fields.append(nameInput, valueWrap);

      const actions = document.createElement("div");
      actions.className = "category-row-actions";
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "icon-mini-button danger";
      deleteButton.title = "删除类目";
      deleteButton.innerHTML = '<svg class="icon"><use href="#icon-trash" /></svg>';
      deleteButton.disabled = isAllCategory(item, index);
      deleteButton.addEventListener("click", () => deleteCategory(index));
      actions.append(deleteButton);

      row.addEventListener("dragstart", (event) => {
        if (isAllCategory(item, index)) {
          event.preventDefault();
          return;
        }
        draggedIndex = index;
        event.dataTransfer.effectAllowed = "move";
      });
      row.addEventListener("dragover", (event) => {
        if (draggedIndex == null) return;
        event.preventDefault();
      });
      row.addEventListener("drop", (event) => {
        event.preventDefault();
        moveCategory(draggedIndex, Number(row.dataset.index));
        draggedIndex = null;
      });
      row.addEventListener("dragend", () => {
        draggedIndex = null;
      });
      row.append(handle, fields, actions);
      list.append(row);
    });
  }

  async function updateCategory(index, patch) {
    const next = categories[index];
    if (!next) return;
    const editingAll = isAllCategory(next, index);
    categories[index] = {
      name: patch.name != null ? patch.name : next.name,
      value: editingAll ? null : patch.value !== undefined ? patch.value : next.value
    };
    await persistCategories();
  }

  async function deleteCategory(index) {
    if (index <= 0) return;
    categories.splice(index, 1);
    await persistCategories();
  }

  async function moveCategory(fromIndex, toIndex) {
    if (!Number.isInteger(fromIndex) || !Number.isInteger(toIndex) || fromIndex <= 0 || toIndex <= 0 || fromIndex === toIndex) return;
    const item = categories.splice(fromIndex, 1)[0];
    categories.splice(Math.max(1, toIndex), 0, item);
    await persistCategories();
  }

  async function addCategory() {
    categories.push({ name: "新类目", value: "200" });
    await persistCategories();
  }

  async function persistCategories() {
    categories = normalizeCategoryList(categories);
    await saveCurrentUserSettings({ categories });
    renderCategories();
  }

  function renderMonitorConfig() {
    const targetInput = document.querySelector("[data-target-path]");
    const allTemplateInput = document.querySelector("[data-all-request-template]");
    const categoryTemplateInput = document.querySelector("[data-category-request-template]");
    if (targetInput) targetInput.value = monitorConfig.targetPath;
    if (allTemplateInput) allTemplateInput.value = JSON.stringify(monitorConfig.allRequestTemplate, null, 2);
    if (categoryTemplateInput) categoryTemplateInput.value = JSON.stringify(monitorConfig.categoryRequestTemplate, null, 2);
  }

  async function saveMonitorConfig() {
    const targetPath = document.querySelector("[data-target-path]").value.trim() || DEFAULT_MONITOR_CONFIG.targetPath;
    const allTemplateText = document.querySelector("[data-all-request-template]").value.trim() || "{}";
    const categoryTemplateText = document.querySelector("[data-category-request-template]").value.trim() || "{}";
    let allRequestTemplate;
    let categoryRequestTemplate;
    try {
      allRequestTemplate = JSON.parse(allTemplateText);
      categoryRequestTemplate = JSON.parse(categoryTemplateText);
    } catch (error) {
      showToast("请求载荷模板不是有效 JSON，请检查后再保存。", "error");
      return;
    }
    monitorConfig = normalizeMonitorConfig({ targetPath, allRequestTemplate, categoryRequestTemplate });
    await saveCurrentUserSettings({ monitorConfig });
    renderMonitorConfig();
    renderPrizeLibrary();
    showToast("更新配置已保存，网页采集面板会自动同步。", "success");
  }

  function getPrizeRecords() {
    return Object.values(prizeLibrary && typeof prizeLibrary === "object" ? prizeLibrary : {})
      .filter((item) => item && item.id)
      .sort((left, right) => String(right.updatedAt || "").localeCompare(String(left.updatedAt || "")));
  }

  function renderPrizeLibrary(reset = true) {
    const grid = document.querySelector("[data-prize-grid]");
    const empty = document.querySelector("[data-prize-empty]");
    const sentinel = document.querySelector("[data-prize-sentinel]");
    const total = document.querySelector("[data-prize-library-total]");
    const search = document.querySelector("[data-prize-search]");
    const categorySelect = document.querySelector("[data-prize-category]");
    if (!grid || !empty || !sentinel || !total) return;
    const all = getPrizeRecords();
    total.textContent = String(all.length);
    const query = search ? search.value.trim().toLowerCase() : "";
    const category = categorySelect ? categorySelect.value : "";
    const categoriesInLibrary = Array.from(new Set(all.flatMap((item) => Array.isArray(item.categories) ? item.categories : []))).filter(Boolean);
    if (categorySelect) {
      const current = categorySelect.value;
      categorySelect.innerHTML = '<option value="">全部类目</option>';
      categoriesInLibrary.forEach((name) => {
        const option = document.createElement("option");
        option.value = name;
        option.textContent = name;
        categorySelect.append(option);
      });
      categorySelect.value = categoriesInLibrary.includes(current) ? current : "";
    }
    const filtered = all.filter((item) => {
      const haystack = `${item.name || ""} ${item.id || ""} ${item.shopName || ""}`.toLowerCase();
      return (!query || haystack.includes(query)) && (!category || (item.categories || []).includes(category));
    });
    if (reset) prizeLibraryVisibleCount = 20;
    grid.innerHTML = "";
    empty.hidden = filtered.length > 0;
    if (!filtered.length) {
      sentinel.hidden = true;
      return;
    }
    filtered.slice(0, prizeLibraryVisibleCount).forEach((item) => grid.append(renderPrizeCard(item)));
    sentinel.hidden = prizeLibraryVisibleCount >= filtered.length;
    sentinel.textContent = prizeLibraryVisibleCount >= filtered.length ? `已展示全部 ${filtered.length} 件奖品` : "继续向下滚动加载更多";
  }

  function renderPrizeCard(item) {
    const card = document.createElement("article");
    card.className = "prize-card";
    const imageWrap = document.createElement("div");
    imageWrap.className = "prize-image-wrap";
    const imageButton = document.createElement("button");
    imageButton.type = "button";
    imageButton.className = "prize-image-button";
    imageButton.title = "查看奖品主图";
    const image = document.createElement("img");
    image.className = "prize-image";
    image.loading = "lazy";
    image.alt = item.name || "奖品主图";
    image.src = item.image || "LOGO.png";
    image.addEventListener("error", () => { image.src = "LOGO.png"; }, { once: true });
    imageButton.append(image);
    imageButton.addEventListener("click", () => openPrizeLightbox(item));
    imageWrap.append(imageButton);
    const info = document.createElement("div");
    info.className = "prize-info";
    const titleRow = document.createElement("div");
    titleRow.className = "prize-title-row";
    const title = document.createElement("button");
    title.type = "button";
    title.className = "prize-name";
    title.textContent = item.name || "未命名奖品";
    title.title = "复制奖品名称";
    title.addEventListener("click", () => copyPrizeText(item.name || "未命名奖品", "奖品名称已复制。", title));
    const idButton = document.createElement("button");
    idButton.type = "button";
    idButton.className = "prize-id-button";
    idButton.title = "复制奖品 ID";
    idButton.innerHTML = `<img class="prize-id-icon" alt="" src="${PRIZE_ID_ICON_SRC}">`;
    idButton.addEventListener("click", () => copyPrizeId(item.id, idButton));
    titleRow.append(title, idButton);
    const categoryRow = document.createElement("div");
    categoryRow.className = "prize-category-row";
    (item.categories || ["全部"]).forEach((name) => {
      const badge = document.createElement("button");
      badge.type = "button";
      badge.className = "prize-category-badge";
      badge.textContent = name;
      badge.title = "复制奖品类目";
      badge.addEventListener("click", () => copyPrizeText(name, "奖品类目已复制。", badge));
      categoryRow.append(badge);
    });
    const tagRow = document.createElement("div");
    tagRow.className = "prize-tag-row";
    (item.tags || []).forEach((tag) => {
      const badge = document.createElement("button");
      badge.type = "button";
      badge.className = getPrizeTagClass(tag);
      badge.textContent = tag;
      badge.title = "复制奖品标签";
      badge.addEventListener("click", () => copyPrizeText(tag, "奖品标签已复制。", badge));
      tagRow.append(badge);
    });
    const shopRow = document.createElement("div");
    shopRow.className = "prize-shop-row";
    const shopIdButton = document.createElement("button");
    shopIdButton.type = "button";
    shopIdButton.className = "shop-id-mark";
    shopIdButton.title = "复制店铺 ID";
    shopIdButton.innerHTML = `<img class="prize-id-icon" alt="" src="${PRIZE_ID_ICON_SRC}">`;
    shopIdButton.addEventListener("click", () => copyPrizeText(item.shopId || "", "店铺 ID 已复制。", shopIdButton));
    const shopName = document.createElement("button");
    shopName.type = "button";
    shopName.className = "shop-name";
    shopName.textContent = item.shopName || "未知店铺";
    shopName.title = "复制店铺名称";
    shopName.addEventListener("click", () => copyPrizeText(item.shopName || "未知店铺", "店铺名称已复制。", shopName));
    const shopScore = document.createElement("button");
    shopScore.type = "button";
    shopScore.className = "shop-score";
    shopScore.textContent = item.shopScore == null ? "--" : `${item.shopScore}分`;
    shopScore.title = "复制店铺体验分";
    shopScore.addEventListener("click", () => copyPrizeText(item.shopScore == null ? "" : String(item.shopScore), "店铺体验分已复制。", shopScore));
    const shopTime = document.createElement("button");
    shopTime.type = "button";
    shopTime.className = "shop-time";
    shopTime.textContent = formatPrizeDate(item.updatedAt);
    shopTime.title = "复制更新时间";
    shopTime.addEventListener("click", () => copyPrizeText(formatPrizeDate(item.updatedAt), "更新时间已复制。", shopTime));
    shopRow.append(shopIdButton, shopName, shopScore, shopTime);
    const divider = document.createElement("div");
    divider.className = "prize-divider";
    const qrButton = document.createElement("button");
    qrButton.type = "button";
    qrButton.className = "prize-qr-button";
    qrButton.title = "打开奖品详情，悬浮可预览二维码";
    qrButton.innerHTML = `<img class="qr-divider-icon" alt="" src="${PRIZE_DIVIDER_ICON_SRC}">`;
    qrButton.addEventListener("click", () => openPrizeDetail(item.id));
    qrButton.addEventListener("mouseenter", () => showQrPreview(qrButton, item.id, item.name || "奖品详情"));
    qrButton.addEventListener("focus", () => showQrPreview(qrButton, item.id, item.name || "奖品详情"));
    qrButton.addEventListener("mouseleave", hideQrPreview);
    qrButton.addEventListener("blur", hideQrPreview);
    divider.append(qrButton);
    const bottomRow = document.createElement("div");
    bottomRow.className = "prize-bottom-row";
    const monthSale = document.createElement("button");
    monthSale.type = "button";
    monthSale.className = "month-sale";
    monthSale.innerHTML = `月发放量：<strong>${formatNumber(item.monthSale)}</strong>`;
    monthSale.title = "复制月发放量";
    monthSale.addEventListener("click", () => copyPrizeText(copyNumericValue(item.monthSale), "月发放量已复制。", monthSale));
    const price = document.createElement("div");
    price.className = "price";
    const regularPrice = document.createElement("button");
    regularPrice.type = "button";
    regularPrice.className = "price-regular";
    regularPrice.textContent = `¥${formatMoney(item.regularPrice)}`;
    regularPrice.title = "复制奖品原价";
    regularPrice.addEventListener("click", () => copyPrizeText(copyNumericValue(item.regularPrice), "奖品原价已复制。", regularPrice));
    const salePrice = document.createElement("button");
    salePrice.type = "button";
    salePrice.className = "price-current";
    salePrice.textContent = `¥${formatMoney(item.price)}`;
    salePrice.title = "复制奖品售价";
    salePrice.addEventListener("click", () => copyPrizeText(copyNumericValue(item.price), "奖品售价已复制。", salePrice));
    price.append(regularPrice, salePrice);
    bottomRow.append(monthSale, price);
    info.append(titleRow, categoryRow, tagRow, shopRow, divider, bottomRow);
    card.append(imageWrap, info);
    return card;
  }

  function formatNumber(value) {
    return value == null ? "--" : new Intl.NumberFormat("zh-CN").format(value);
  }

  function formatMoney(value) {
    return value == null ? "--" : Number(value).toFixed(2).replace(/\.00$/, "");
  }

  function copyNumericValue(value) {
    return value == null ? "" : String(value).replace(/,/g, "");
  }

  function formatPrizeDate(value) {
    if (!value) return "--";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? "--" : date.toLocaleString("zh-CN", { hour12: false }).replace(/-/g, "/");
  }

  function openPrizeLightbox(item) {
    const overlay = document.createElement("div");
    overlay.className = "prize-lightbox-overlay";
    overlay.innerHTML = `
      <div class="prize-lightbox-stage" role="dialog" aria-modal="true" aria-label="查看奖品主图">
        <div class="prize-lightbox-toolbar">
          <span>奖品主图</span>
          <button type="button" class="prize-lightbox-close" aria-label="关闭">×</button>
        </div>
        <div class="prize-lightbox-media">
          <img class="prize-lightbox-image" alt="${escapeHtml(item.name || "奖品主图")}" src="${escapeHtml(item.image || "LOGO.png")}">
        </div>
        <div class="prize-lightbox-caption">${escapeHtml(item.name || "奖品主图")}</div>
      </div>
    `;
    const previousOverflow = document.body.style.overflow;
    const lightboxImage = overlay.querySelector(".prize-lightbox-image");
    lightboxImage?.addEventListener("error", () => {
      lightboxImage.src = "LOGO.png";
    }, { once: true });
    const onKeyDown = (event) => {
      if (event.key === "Escape") close();
    };
    const close = () => {
      overlay.remove();
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
    overlay.addEventListener("click", (event) => { if (event.target === overlay) close(); });
    overlay.querySelector(".prize-lightbox-close")?.addEventListener("click", close);
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    document.body.append(overlay);
  }

  function getPrizeTagClass(tag) {
    const tagMap = {
      抖音旗舰: "tag-flagship",
      引流利器: "tag-traffic",
      引流神器: "tag-traffic",
      口碑好物: "tag-reputation",
      心动超值: "tag-value",
      支持开票: "tag-invoice"
    };
    return `prize-tag ${tagMap[tag] || ""}`.trim();
  }

  function handlePrizeLibraryChange() {
    prizeLibraryVisibleCount = 20;
    renderPrizeLibrary(false);
  }

  async function copyPrizeId(id, button) {
    await copyPrizeText(String(id), "奖品 ID 已复制。", button);
  }

  async function copyPrizeText(text, message, button) {
    try {
      await navigator.clipboard.writeText(String(text));
    } catch (error) {
      const input = document.createElement("textarea");
      input.value = String(text);
      document.body.append(input);
      input.select();
      document.execCommand("copy");
      input.remove();
    }
    button?.classList?.add("copied");
    showToast(message, "success");
    window.setTimeout(() => button?.classList?.remove("copied"), 1200);
  }

  let qrPreviewEl = null;

  function getPrizeDetailUrl(id) {
    return `https://buyin.jinritemai.com/dashboard/merch-picking-hall/luckybag-detail?id=${encodeURIComponent(id || "")}`;
  }

  function openPrizeDetail(id) {
    if (!id) return;
    window.open(getPrizeDetailUrl(id), "_blank", "noopener,noreferrer");
  }

  function showQrPreview(anchor, id, title) {
    if (!anchor || !id) return;
    hideQrPreview();
    const detailUrl = getPrizeDetailUrl(id);
    qrPreviewEl = document.createElement("div");
    qrPreviewEl.className = "qr-preview-popover";
    qrPreviewEl.innerHTML = `
      <div class="qr-preview-title">${escapeHtml(title)}</div>
      <img alt="奖品详情二维码" src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&margin=10&data=${encodeURIComponent(detailUrl)}">
      <div class="qr-preview-note">扫码查看奖品详情</div>
    `;
    document.body.append(qrPreviewEl);
    const rect = anchor.getBoundingClientRect();
    const pop = qrPreviewEl.getBoundingClientRect();
    const left = Math.max(16, Math.min(window.innerWidth - pop.width - 16, rect.left + rect.width / 2 - pop.width / 2));
    const top = Math.max(16, rect.top - pop.height - 12);
    qrPreviewEl.style.left = `${left}px`;
    qrPreviewEl.style.top = `${top}px`;
  }

  function hideQrPreview() {
    if (!qrPreviewEl) return;
    qrPreviewEl.remove();
    qrPreviewEl = null;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>\"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }

  async function exportConfig() {
    const payload = {
      version: 1,
      exportedAt: new Date().toISOString(),
      username: isLoggedIn() ? authState.username : "guest",
      categories,
      monitorConfig
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `buyin-luckybag-config-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast("配置已导出为 JSON 文件。", "success");
  }

  async function importConfig(file) {
    if (!file) return;
    try {
      const payload = JSON.parse(await file.text());
      categories = normalizeCategoryList(payload.categories || DEFAULT_CATEGORIES);
      monitorConfig = normalizeMonitorConfig(payload.monitorConfig || DEFAULT_MONITOR_CONFIG);
      await saveCurrentUserSettings({ categories, monitorConfig });
      renderCategories();
      renderMonitorConfig();
      showToast("配置已导入。", "success");
    } catch (error) {
      showToast("导入失败，请确认文件是有效的 JSON 配置。", "error");
    }
  }

  function initEvents() {
    document.querySelectorAll("[data-app-version]").forEach((node) => {
      node.textContent = manifest.version || "1.8.6";
    });
    document.querySelectorAll("[data-release-page]").forEach((node) => {
      node.setAttribute("href", RELEASE_PAGE_URL);
    });
    document.querySelectorAll("[data-latest-version]").forEach((node) => { node.textContent = "尚未检查"; });
    updateDownloadActions("", false, "ready");
    document.querySelectorAll("[data-theme-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        activeTheme = button.dataset.themeChoice;
        storage.setItem("buyinOptionsTheme", activeTheme);
        applyTheme();
      });
    });
    const languageSelect = document.getElementById("languageSelect");
    languageSelect.addEventListener("change", () => {
      activeLanguage = languageSelect.value;
      storage.setItem("buyinOptionsLanguage", activeLanguage);
      applyLanguage();
      renderSearchResults(document.getElementById("settingSearch").value);
    });
    document.getElementById("sidebarToggle").addEventListener("click", () => {
      const next = root.dataset.sidebarCollapsed !== "true";
      root.dataset.sidebarCollapsed = String(next);
      storage.setItem("buyinOptionsSidebarCollapsed", String(next));
    });
    document.querySelectorAll(".tab").forEach((tab) => {
      tab.addEventListener("click", () => {
        setActiveTab(tab.dataset.tab, false);
        if (tab.dataset.tab === "prizes") renderPrizeLibrary();
      });
    });
    document.querySelector("[data-prize-search]")?.addEventListener("input", handlePrizeLibraryChange);
    document.querySelector("[data-prize-category]")?.addEventListener("change", handlePrizeLibraryChange);
    document.getElementById("settingSearch").addEventListener("input", (event) => renderSearchResults(event.target.value));
    document.addEventListener("click", (event) => {
      if (!event.target.closest(".search-wrap")) document.getElementById("searchResults").hidden = true;
    });
    document.getElementById("checkUpdate").addEventListener("click", handleCheckUpdate);
    document.querySelector("[data-about-check-update]")?.addEventListener("click", handleCheckUpdate);
    document.querySelector("[data-category-add]").addEventListener("click", addCategory);
    document.querySelector("[data-save-monitor-config]").addEventListener("click", saveMonitorConfig);
    document.querySelector("[data-export-config]").addEventListener("click", exportConfig);
    document.querySelector("[data-import-config]").addEventListener("click", () => document.querySelector("[data-import-file]").click());
    document.querySelector("[data-import-file]").addEventListener("change", (event) => importConfig(event.target.files[0]));
    if (storage.getItem("buyinOptionsSidebarCollapsed") === "true") root.dataset.sidebarCollapsed = "true";
    prefersDark.addEventListener("change", applyTheme);
    loadReleaseNotes();
    watchSharedStorage();
    const sentinel = document.querySelector("[data-prize-sentinel]");
    if (sentinel && "IntersectionObserver" in window) {
      prizeLibraryObserver = new IntersectionObserver((entries) => {
        if (!entries.some((entry) => entry.isIntersecting)) return;
        const all = getPrizeRecords();
        const query = document.querySelector("[data-prize-search]")?.value.trim().toLowerCase() || "";
        const category = document.querySelector("[data-prize-category]")?.value || "";
        const filteredCount = all.filter((item) => {
          const haystack = `${item.name || ""} ${item.id || ""} ${item.shopName || ""}`.toLowerCase();
          return (!query || haystack.includes(query)) && (!category || (item.categories || []).includes(category));
        }).length;
        if (prizeLibraryVisibleCount < filteredCount) {
          prizeLibraryVisibleCount += 20;
          renderPrizeLibrary(false);
        }
      }, { rootMargin: "320px" });
      prizeLibraryObserver.observe(sentinel);
    }
  }

  function watchSharedStorage() {
    const api = typeof browser !== "undefined" && browser.storage ? browser.storage : typeof chrome !== "undefined" && chrome.storage ? chrome.storage : null;
    if (!api || !api.onChanged) return;
    api.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") return;
      if (changes[STORAGE_KEYS.auth]) {
        authState = changes[STORAGE_KEYS.auth].newValue || { mode: "guest", username: "" };
        loadSharedState();
        return;
      }
      if (changes[STORAGE_KEYS.users]) {
        users = changes[STORAGE_KEYS.users].newValue || {};
        renderUserMetrics();
      }
      if (changes[STORAGE_KEYS.userSettings]) {
        const settings = normalizeUserSettings((changes[STORAGE_KEYS.userSettings].newValue || {})[authState.username]);
        categories = settings.categories;
        monitorConfig = settings.monitorConfig;
        renderCategories();
        renderMonitorConfig();
      }
      if (changes[STORAGE_KEYS.prizeLibrary]) {
        prizeLibrary = changes[STORAGE_KEYS.prizeLibrary].newValue || {};
        renderUserMetrics();
        renderPrizeLibrary(false);
      }
    });
  }

  async function loadCurrentUserSettings() {
    if (!isLoggedIn()) return normalizeUserSettings();
    const userSettings = await storageGet(STORAGE_KEYS.userSettings, {});
    return normalizeUserSettings(userSettings[authState.username]);
  }

  async function saveCurrentUserSettings(patch) {
    if (!isLoggedIn()) return;
    const userSettings = await storageGet(STORAGE_KEYS.userSettings, {});
    const current = normalizeUserSettings(userSettings[authState.username]);
    userSettings[authState.username] = normalizeUserSettings(Object.assign({}, current, patch));
    await storageSet({ [STORAGE_KEYS.userSettings]: userSettings });
  }

  function renderUserMetrics() {
    const userList = Object.values(users && typeof users === "object" ? users : {});
    const prizeList = getPrizeRecords();
    const today = new Date();
    const todayKey = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
    metrics.accountTotal = userList.length;
    metrics.newUsers = userList.filter((user) => {
      const date = new Date(Number(user && user.createdAt) || 0);
      return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}` === todayKey;
    }).length;
    metrics.prizeTotal = prizeList.length;
    metrics.newPrizes = prizeList.filter((item) => isToday(item.createdAt || item.updatedAt, todayKey)).length;
    const shops = new Map();
    prizeList.forEach((item) => {
      const shopId = String(item.shopId || item.shopName || "");
      if (!shopId || shops.has(shopId)) return;
      shops.set(shopId, item);
    });
    metrics.shopTotal = shops.size;
    metrics.newShops = Array.from(shops.values()).filter((item) => isToday(item.createdAt || item.updatedAt, todayKey)).length;
    renderMetrics();
  }

  function isToday(value, todayKey) {
    const date = new Date(value || 0);
    return !Number.isNaN(date.getTime()) && `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}` === todayKey;
  }

  async function handleCheckUpdate() {
    const currentVersion = manifest.version || "1.8.6";
    const status = document.getElementById("updateStatus");
    const buttons = Array.from(document.querySelectorAll("#checkUpdate, [data-about-check-update]"));
    buttons.forEach((button) => { button.disabled = true; });
    updateDownloadActions("", false, "checking");
    if (status) status.textContent = "正在检查更新...";
    showToast("正在检查公开发布仓库版本...", "info");
    try {
      const latest = await fetchLatestGitHubVersion();
      const checkedAt = new Date().toLocaleString("zh-CN", { hour12: false });
      storage.setItem("buyinLastUpdateCheck", checkedAt);
      storage.setItem("buyinLatestVersion", latest.version);
      document.querySelectorAll("[data-latest-version]").forEach((node) => { node.textContent = latest.version; });
      document.querySelectorAll("[data-last-check]").forEach((node) => { node.textContent = checkedAt; });
      const hasUpdate = compareVersions(latest.version, currentVersion) > 0;
      updateDownloadActions(latest.version, hasUpdate, hasUpdate ? "available" : "current");
      if (hasUpdate) {
        if (status) status.textContent = `发现新版本 v${latest.version}，可直接下载更新包。`;
        showToast(`发现新版本 v${latest.version}，可立即下载。`, "warning");
      } else {
        if (status) status.textContent = `当前已是最新版本 (v${currentVersion})`;
        showToast(`当前已是最新版本 v${currentVersion}。`, "success");
      }
    } catch (error) {
      const checkedAt = new Date().toLocaleString("zh-CN", { hour12: false });
      storage.setItem("buyinLastUpdateCheck", checkedAt);
      storage.removeItem("buyinLatestVersion");
      document.querySelectorAll("[data-latest-version]").forEach((node) => { node.textContent = "检查失败"; });
      document.querySelectorAll("[data-last-check]").forEach((node) => { node.textContent = checkedAt; });
      updateDownloadActions("", false, "failed");
      if (status) status.textContent = error && error.message ? error.message : "检查失败，请稍后重试。";
      showToast(status ? status.textContent : "检查失败，请稍后重试。", "error");
    } finally {
      if (updateActionState === "checking") buttons.forEach((button) => { button.disabled = false; });
    }
  }

  async function fetchLatestGitHubVersion() {
    const tags = await fetchGitHubJson(`${RELEASE_API_BASE}/tags?per_page=100`).catch(() => null);
    const versions = Array.isArray(tags)
      ? tags
        .map((item) => item && item.name ? normalizeVersion(item.name) : "")
        .filter(Boolean)
        .sort((left, right) => compareVersions(right, left))
      : [];
    if (versions.length) {
      return { version: versions[0], source: "tag" };
    }
    throw new Error("检查失败：无法访问公开发布仓库的 tags。请确认公开发布仓库已创建并发布版本标签。");
  }

  function updateDownloadActions(version, hasUpdate, state = "ready") {
    updateActionState = state;
    const checkButtons = document.querySelectorAll("#checkUpdate, [data-about-check-update]");
    checkButtons.forEach((button) => {
      button.hidden = state === "available";
      button.disabled = state === "checking" || state === "current";
      const label = button.querySelector("span");
      if (label) label.textContent = state === "current" ? "已是最新版本" : "立即更新";
    });
    document.querySelectorAll("[data-download-zip], [data-download-tar]").forEach((node) => {
      if (!(node instanceof HTMLAnchorElement)) return;
      if (state !== "available" || !hasUpdate || !version) {
        node.hidden = true;
        node.removeAttribute("href");
        return;
      }
      const suffix = `v${normalizeVersion(version)}`;
      node.hidden = false;
      node.href = node.matches("[data-download-zip]")
        ? `${RELEASE_ARCHIVE_BASE}/${suffix}.zip`
        : `${RELEASE_ARCHIVE_BASE}/${suffix}.tar.gz`;
    });
  }

  async function loadReleaseNotes() {
    const list = document.querySelector("[data-release-list]");
    if (!list) return;
    try {
      const payload = await fetchGitHubJson(RELEASE_CHANGELOG_URL);
      const releases = Array.isArray(payload) ? payload : payload.releases;
      if (!Array.isArray(releases) || !releases.length) throw new Error("empty release notes");
      list.innerHTML = "";
      releases
        .slice()
        .sort((left, right) => compareVersions(right.version, left.version))
        .forEach((release, index) => {
          const details = document.createElement("details");
          details.className = "release-item";
          details.open = index < 2;
          const summary = document.createElement("summary");
          const version = document.createElement("span");
          version.textContent = `v${normalizeVersion(release.version)}`;
          const title = document.createElement("strong");
          title.textContent = release.title || "版本更新";
          summary.append(version, title);
          details.append(summary);
          (Array.isArray(release.notes) ? release.notes : [release.notes || "暂无更新说明。"])
            .filter(Boolean)
            .forEach((note) => {
              const paragraph = document.createElement("p");
              paragraph.textContent = note;
              details.append(paragraph);
            });
          list.append(details);
        });
    } catch (error) {
      list.innerHTML = "<p class=\"release-loading\">暂时无法加载更新记录，请稍后重试。</p>";
    }
  }

  function showToast(message, type = "info") {
    if (!toastRoot) {
      toastRoot = document.createElement("div");
      toastRoot.className = "toast-stack";
      toastRoot.setAttribute("aria-live", "polite");
      document.body.appendChild(toastRoot);
    }
    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;
    const dot = document.createElement("span");
    dot.className = "toast-dot";
    const text = document.createElement("span");
    text.className = "toast-text";
    text.textContent = message;
    toast.append(dot, text);
    toastRoot.appendChild(toast);
    while (toastRoot.children.length > 3) toastRoot.firstElementChild.remove();
    window.setTimeout(() => {
      toast.classList.add("is-leaving");
      window.setTimeout(() => toast.remove(), 180);
    }, 3000);
  }

  async function fetchGitHubJson(url) {
    const response = await fetch(url, {
      headers: {
        Accept: "application/vnd.github+json"
      }
    });
    if (!response.ok) throw new Error(`GitHub API ${response.status}`);
    return response.json();
  }

  function normalizeVersion(version) {
    return String(version || "0.0.0").trim().replace(/^v/i, "") || "0.0.0";
  }

  function compareVersions(left, right) {
    const leftParts = normalizeVersion(left).split(/[.-]/).map((part) => Number.parseInt(part, 10) || 0);
    const rightParts = normalizeVersion(right).split(/[.-]/).map((part) => Number.parseInt(part, 10) || 0);
    const length = Math.max(leftParts.length, rightParts.length);
    for (let index = 0; index < length; index += 1) {
      const diff = (leftParts[index] || 0) - (rightParts[index] || 0);
      if (diff !== 0) return diff;
    }
    return 0;
  }

  function storageGet(key, fallback) {
    const area = getStorageArea();
    if (!area) return Promise.resolve(fallback);
    if (typeof browser !== "undefined" && browser.storage) {
      return area.get(key).then((result) => (Object.prototype.hasOwnProperty.call(result, key) ? result[key] : fallback)).catch(() => fallback);
    }
    return new Promise((resolve) => {
      area.get(key, (result) => resolve(result && Object.prototype.hasOwnProperty.call(result, key) ? result[key] : fallback));
    });
  }

  function storageSet(values) {
    const area = getStorageArea();
    if (!area) return Promise.resolve();
    if (typeof browser !== "undefined" && browser.storage) return area.set(values).catch(() => undefined);
    return new Promise((resolve) => area.set(values, resolve));
  }

  function getStorageArea() {
    const api = typeof browser !== "undefined" && browser.storage ? browser.storage : typeof chrome !== "undefined" && chrome.storage ? chrome.storage : null;
    return api && api.local ? api.local : null;
  }

  function isLoggedIn() {
    return authState && authState.mode === "user" && Boolean(authState.username);
  }

  function normalizeCategoryList(list) {
    const source = Array.isArray(list) ? list : [];
    const allCategory = source.find((item) => isAllCategory(item)) || { name: "全部", value: null };
    const others = source
      .filter((item) => !isAllCategory(item))
      .map((item) => ({ name: String(item.name || "").trim(), value: normalizeCategoryValue(item.value) }))
      .filter((item) => item.name);
    return [{ name: allCategory.name || "全部", value: null }].concat(others);
  }

  function isAllCategory(item, index) {
    if (!item) return false;
    if (index === 0 && normalizeCategoryValue(item.value) === null) return true;
    return normalizeCategoryValue(item.value) === null && String(item.name || "").trim() === "全部";
  }

  function normalizeCategoryValue(value) {
    const text = value == null ? "" : String(value).trim();
    return text ? text : null;
  }

  function normalizeMonitorConfig(config) {
    const source = config && typeof config === "object" ? config : DEFAULT_MONITOR_CONFIG;
    const legacyTemplate = source.requestTemplate && typeof source.requestTemplate === "object" ? source.requestTemplate : null;
    const allRequestTemplate = source.allRequestTemplate && typeof source.allRequestTemplate === "object" ? source.allRequestTemplate : cloneJson(DEFAULT_MONITOR_CONFIG.allRequestTemplate);
    const categoryRequestTemplate = source.categoryRequestTemplate && typeof source.categoryRequestTemplate === "object" ? source.categoryRequestTemplate : legacyTemplate || cloneJson(DEFAULT_MONITOR_CONFIG.categoryRequestTemplate);
    return {
      targetPath: String(source.targetPath || DEFAULT_MONITOR_CONFIG.targetPath).trim() || DEFAULT_MONITOR_CONFIG.targetPath,
      allRequestTemplate,
      categoryRequestTemplate,
      requestTemplate: categoryRequestTemplate
    };
  }

  function cloneJson(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function normalizeUserSettings(settings) {
    const source = settings && typeof settings === "object" ? settings : {};
    return {
      categories: normalizeCategoryList(source.categories || cloneJson(DEFAULT_CATEGORIES)),
      monitorConfig: normalizeMonitorConfig(source.monitorConfig || cloneJson(DEFAULT_MONITOR_CONFIG))
    };
  }

  async function init() {
    initEvents();
    applyTheme();
    applyLanguage();
    const lastCheck = storage.getItem("buyinLastUpdateCheck") || "尚未检查";
    document.querySelectorAll("[data-latest-version]").forEach((node) => { node.textContent = "尚未检查"; });
    document.querySelectorAll("[data-last-check]").forEach((node) => { node.textContent = lastCheck; });
    await loadSharedState();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
