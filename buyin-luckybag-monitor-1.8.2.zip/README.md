# 巨量百应超级福袋采集助手

这是一个兼容 Chrome、Edge、Firefox 等现代浏览器的 WebExtension 扩展。扩展会在巨量百应超级福袋页面中监测指定网络请求，展示请求载荷与响应数据，并支持按奖品类目自动滚动采集瀑布流数据。

## 监测范围

- 目标页面：`https://buyin.jinritemai.com/dashboard/merch-picking-hall/luckybag`
- 页面地址允许携带参数，例如：`luckybag?xxx=yyy`
- 默认目标请求：`/pc/selection/common/material_list`
- 请求地址允许携带任意查询参数，例如：`material_list?ewid=...&msToken=...&a_bogus=...`

## 目标请求配置规则

在“扩展程序选项 -> 设置 -> 后续更新”中可以修改目标网络请求，支持三种写法：

- `/pc/selection/common/material_list`：只匹配路径，忽略域名、协议和查询参数。官方域名变化但路径不变时，推荐使用这种方式。
- `//buyin.jinritemai.com/pc/selection/common/material_list`：匹配指定域名和路径，忽略协议与查询参数。
- `https://buyin.jinritemai.com/pc/selection/common/material_list`：匹配完整来源和路径，忽略查询参数。

也就是说，默认 `/pc/selection/common/material_list` 可以识别 `https://buyin.jinritemai.com/pc/selection/common/material_list?ewid=...&msToken=...&a_bogus=...` 这类完整请求。若官方接口路径变成 `/chat/api/new/backstage/get_unread_msg_count`，后台填写这个路径即可按“路径模式”识别任意域名下的同路径请求；若需要锁定某个域名，则使用 `//域名/路径` 或完整 URL。

## 请求载荷模板

后台“后续更新”板块包含两份模板：

- 全部类目请求载荷模板：默认 `{"filters": {}}`，用于识别和构造“全部”类目的请求。
- 具体类目请求载荷模板：默认 `{"filters": {"BusinessCid": {"value": ["__CATEGORY_ID__"]}}}`，其中 `__CATEGORY_ID__` 是类目 ID 占位符。

扩展会根据具体类目模板中 `__CATEGORY_ID__` 的位置反向识别真实请求载荷里的类目 ID。例如未来官方载荷改为 `{"scene":"PCLuckyBagSelection","extra":{"industry_id":"9"}}`，只需要把具体类目模板改成 `{"scene":"PCLuckyBagSelection","extra":{"industry_id":"__CATEGORY_ID__"}}`，默认类目 ID 不变时即可继续识别美妆等类目。

如果未来全部类目载荷改成 `{"scene":"PCLuckyBagSelection","extra":{}}`，把全部类目模板改成这份 JSON 即可，扩展不会额外强行补入旧的 `filters` 结构。

模板采用“子结构匹配”：模板里写到的字段必须能在真实请求载荷中找到并匹配，真实载荷允许包含额外字段。因此在当前官方载荷仍是 `filters.BusinessCid.value` 时，如果故意把模板改成 `{"extra":{"industry_id":["__CATEGORY_ID__"]}}`，扩展会识别失败，这是正常表现，说明模板配置已经真正生效。

## 当前功能

- 打开或刷新目标页面后自动启用。
- 同时监听 `fetch` 和 `XMLHttpRequest` 请求。
- 展示目标请求的 URL、请求方式、状态码、请求类型、请求载荷和响应数据。
- 响应数据区域提供复制按钮，可一键复制当前响应内容。
- 根据请求载荷自动识别奖品类目，并根据响应数据中的 `data.summary_promotions` 统计当前请求采集到的奖品数量。
- 提供“开始采集”按钮，自动展开网页奖品类目导航栏，并持续置底可滚动容器以加载瀑布流数据。
- 支持自定义采集速度，默认每次随机等待 `2000ms-3000ms`。
- 检测到页面出现“没有更多了”时会自动置底并结束当前类目采集。
- 奖品类目按钮支持单击选中/取消、双击编辑、长按拖动排序、新增和删除。
- “全部”类目固定第一位，不支持删除和拖动。
- 可选择多个类目按当前顺序依次采集。
- 支持本机扩展账号注册/登录；登录后每个账号拥有独立配置，游客模式下的配置刷新后恢复默认。
- 提供扩展程序选项页，包含首页总览、奖品总库、奖品店铺、奖品排行榜、设置、关于等标签页。
- 设置页支持奖品类目管理、目标请求与请求载荷模板维护、配置 JSON 导入/导出。
- 关于页支持版本检查、GitHub 仓库入口、项目官网入口、技术栈说明和更新记录。
- 前台采集面板和后台选项页使用右下角气泡通知展示关键操作结果。
- 新增奖品总库：开始采集时保存当前响应及后续采集数据，按奖品 ID 去重更新，支持搜索、类目筛选、每页 20 条瀑布流加载和复制奖品 ID。

## 更新检查

扩展的“检查更新”会读取公开发布仓库 `52xd/buyin-luckybag-monitor-release` 的 GitHub Releases 最新版本；如果没有 Release，则回退读取 Git tag。源码仓库仍保持私有，公开发布仓库只需要保存打包后的 `.zip`、`.crx`、简短 README 和版本标签即可。

推荐每次发布新版本时，在公开发布仓库创建同名 tag，例如 `v1.8.1`，并上传最新扩展压缩包与 CRX 安装包。用户点击“下载最新版本”后会进入公开发布仓库的最新 Release 页面。

## 本地安装方式

### Chrome / Edge 加载未打包扩展

1. 打开浏览器扩展管理页面：Chrome 为 `chrome://extensions/`，Edge 为 `edge://extensions/`。
2. 开启“开发者模式”。
3. 点击“加载已解压的扩展程序”。
4. 选择本项目文件夹。
5. 打开或刷新巨量百应超级福袋页面，即可看到右上角采集面板。

### CRX 安装包

项目可使用 Chrome/Edge 的 `--pack-extension` 生成 `.crx` 安装包。生成 CRX 时会同时生成私钥 `.pem`，请妥善保存私钥；后续更新必须使用同一私钥打包，浏览器才会认为是同一个扩展。

Chrome 对本地 CRX 安装有安全限制，通常需要在扩展管理页开启开发者模式后拖入安装包，企业分发或正式商店发布则需要按对应浏览器平台要求处理。

### Firefox 临时加载

1. 打开 `about:debugging#/runtime/this-firefox`。
2. 点击“临时载入附加组件”。
3. 选择项目中的 `manifest.json`。

## 项目文件说明

- `manifest.json`：浏览器扩展配置文件。
- `background.js`：扩展后台脚本。
- `content-script.js`：负责渲染采集面板、类目管理、账号状态和采集状态机。
- `page-hook.js`：注入网页上下文，负责网络请求监听、真实类目点击、导航展开和滚动容器置底。
- `options.html`、`options.css`、`options.js`：扩展程序选项页。
- `LOGO.png`：扩展图标和选项页品牌标识。
- `buyin-luckybag-monitor.zip`：本地生成的扩展压缩包，不纳入 Git 管理。

## 版本记录

- `v1.8.2`：新增奖品总库，支持采集数据按奖品 ID 持久化、合并更新、搜索筛选和瀑布流加载。
- `v1.8.1`：切换到公开发布仓库检查更新，新增前后台右下角气泡通知，并同步更新发行包。
- `v1.8.0`：完善设置页、关于页、更新检查、目标请求匹配规则和请求载荷模板识别。
- `v1.7.0`：优化整体 UI 质感，完善账号入口、设置页类目管理和关于页基础信息。
- `v1.6.0`：新增扩展程序选项页与首页总览。
- `v1.5.0`：修复重复采集启动、中文扩展名称和 LOGO 使用。
- `v1.4.0`：修复浏览器扩展错误提示，优化 page hook 事件处理。
- `v1.3.0`：完善网页类目导航展开和真实类目切换。
- `v1.2.0`：新增多类目选择、排序、新增、编辑和依次采集。
- `v1.1.0`：新增采集速度范围设置、后台标签页切换时持续采集。
- `v1.0.0`：实现目标请求监听、响应展示、复制和基础自动滚动采集。

## 后续计划

当前版本仍保持原生 WebExtensions 实现，方便直接加载、调试和跨浏览器验证。后续进入完整工程化阶段时，可以迁移到 WXT + React + TypeScript，并结合 Tailwind CSS 与 Radix UI 建立更系统的组件体系。
